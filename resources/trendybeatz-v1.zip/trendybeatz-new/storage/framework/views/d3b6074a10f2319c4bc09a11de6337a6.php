

<?php
    $pageTitle = $post->title . ' — TrendyBeatz';

    $cleanMetaText = static function ($text): string {
        return trim(preg_replace(
            '/\s+/u',
            ' ',
            html_entity_decode(
                strip_tags((string) $text),
                ENT_QUOTES | ENT_HTML5,
                'UTF-8'
            )
        ));
    };

    $pageDescription = collect([
        $post->intro ?? '',
        $post->description ?? '',
    ])
        ->map($cleanMetaText)
        ->filter(fn ($text) => $text !== '')
        ->implode(' ');

    if ($pageDescription === '') {
        $pageDescription = 'Read ' . $post->title
            . ' and more news on TrendyBeatz.';
    }

    $pageDescription = \Illuminate\Support\Str::limit(
        $pageDescription,
        260,
        ''
    );

    $metaKeywords = collect([
        $cleanMetaText($post->title),
        $cleanMetaText($post->keywords ?? ''),
        $cleanMetaText($post->category_name ?? ''),
        'TrendyBeatz blog',
        'TrendyBeatz news',
    ])
        ->filter(fn ($value) => $value !== '')
        ->unique()
        ->implode(', ');

    $canonicalUrl = route('blogs.show', $post->slug);

    $cover = trim((string) ($post->photo ?? ''));

    if ($cover === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $cover)) {
        $socialImage = $cover;
    } else {
        $coverPath = ltrim($cover, '/');

        $socialImage = asset(
            str_starts_with($coverPath, 'images/blog/')
                ? $coverPath
                : 'images/blog/' . basename($coverPath)
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('meta_keywords', $metaKeywords); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $post->title); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>



<?php $__env->startSection('content'); ?>
    <?php
        $postedAt = $post->updated_at
            ? \Illuminate\Support\Carbon::parse($post->updated_at)
            : null;

        $categoryClasses = [
            'sport-news' => 'tb-blog-sport',
            'celebrity-news' => 'tb-blog-celebrity',
            'hot-gists' => 'tb-blog-gists',
            'networth' => 'tb-blog-networth',
            'music-reviews' => 'tb-blog-reviews',
            'education' => 'tb-blog-education',
            'articles' => 'tb-blog-articles',
            'news' => 'tb-blog-news',
        ];

        $categoryClass = $categoryClasses[$post->category_slug]
            ?? 'tb-blog-news';
    
        
        $imageUrl = function ($value) {
            $image = trim((string) $value);

            if ($image === '') {
                return null;
            }

            if (preg_match('~^https?://~i', $image)) {
                return $image;
            }

            $path = ltrim($image, '/');

            return asset(
                str_starts_with($path, 'images/blog/')
                    ? $path
                    : 'images/blog/' . basename($path)
            );
        };

        $contentBlocks = [
            ['text', $post->description],
            ['text', $post->desc2],
            ['text', $post->desc3],
            ['image', $post->photo2],
            ['text', $post->desc4],
            ['text', $post->desc5],
            ['text', $post->desc6],
            ['image', $post->photo3],
            ['text', $post->desc7],
            ['text', $post->desc8],
            ['text', $post->desc9],
            ['image', $post->photo4],
            ['text', $post->desc10],
            ['text', $post->Desc11],
            ['text', $post->Desc12],
            ['text', $post->Desc13],
            ['image', $post->photo5],
            ['text', $post->Desc14],
            ['text', $post->Desc15],
            ['text', $post->Desc16],
            ['image', $post->photo6],
            ['text', $post->Desc17],
            ['text', $post->Desc18],
            ['text', $post->Desc19],
            ['image', $post->photo7],
            ['text', $post->Desc20],
            ['text', $post->Desc21],
            ['text', $post->Desc22],
            ['text', $post->Desc23],
            ['image', $post->photo8],
            ['text', $post->Desc24],
            ['text', $post->Desc25],
            ['text', $post->Desc26],
            ['image', $post->photo9],
            ['text', $post->Desc27],
            ['text', $post->Desc28],
            ['text', $post->Desc29],
            ['image', $post->photo10],
            ['text', $post->Desc30],
        ];

        $readingParts = [(string) ($post->intro ?? '')];

        foreach ($contentBlocks as [$type, $value]) {
            if ($type === 'text' && filled($value)) {
                $readingParts[] = (string) $value;
            }
        }

        $readingText = implode(' ', $readingParts);

        // Remove markup while preserving spaces between paragraphs.
        $readingText = preg_replace('/<[^>]*>/u', ' ', $readingText);

        $readingText = html_entity_decode(
            $readingText,
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );

        $words = preg_split(
            '/[\s\p{Z}]+/u',
            trim($readingText),
            -1,
            PREG_SPLIT_NO_EMPTY
        );

        $wordCount = count($words ?: []);

        $readingMinutes = max(1, (int) ceil($wordCount / 200));
    ?>

    <div class="tb-article-page">
        <nav class="tb-article-breadcrumbs" aria-label="Breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span aria-hidden="true">→</span>

            <a href="<?php echo e(route('blogs.index')); ?>">Blog</a>
            <span aria-hidden="true">→</span>

            <?php if($post->category_slug): ?>
                <a href="<?php echo e(route('blogs.category', $post->category_slug)); ?>">
                    <?php echo e($post->category_name); ?>

                </a>
                <span aria-hidden="true">→</span>
            <?php endif; ?>

            <span aria-current="page">
                <?php echo e($post->title); ?>

            </span>
        </nav>

        <nav class="tb-article-categories" aria-label="Blog categories">
            <a
                class="tb-article-category-link"
                href="<?php echo e(route('blogs.index')); ?>"
            >
                All
            </a>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    href="<?php echo e(route('blogs.category', $category->slug)); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'tb-article-category-link',
                        'active' => $category->id === $post->category_id,
                    ]); ?>"
                >
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <article class="tb-article-main">
            <div class="tb-article-cover">
                <span class="tb-article-placeholder" aria-hidden="true">
                    TrendyBlog
                </span>

                <?php if($socialImage !== ''): ?>
                    <img
                        src="<?php echo e($socialImage); ?>"
                        alt="<?php echo e($post->title); ?>"
                        onerror="this.remove()"
                    >
                <?php endif; ?>
            </div>

            <div class="tb-article-meta">
                <a
                    class="tb-article-badge <?php echo e($categoryClass); ?>"
                    href="<?php echo e(route('blogs.category', [
                        'category' => $post->category_slug,
                    ])); ?>"
                    style="text-decoration: none;"
                >
                    <?php echo e($post->category_name ?: 'News'); ?>

                </a>

                <?php if(filled($post->posted_by_name)): ?>
                    <span class="tb-article-meta-item">
                        <span aria-hidden="true">✍</span>
                        <a
                            href="<?php echo e(route('blogs.published_by', [
                                'slug' => \Illuminate\Support\Str::slug($post->posted_by_name),
                            ])); ?>"
                        >
                            <strong><?php echo e($post->posted_by_name); ?></strong>
                        </a>
                    </span>
                <?php endif; ?>

                <?php if($postedAt): ?>
                    <span class="tb-article-meta-item">
                        <span aria-hidden="true">🗓</span>
                        <time datetime="<?php echo e($postedAt->toDateString()); ?>">
                            <?php echo e($postedAt->format('d M Y')); ?>

                        </time>
                    </span>
                <?php endif; ?>

                <span class="tb-article-meta-item">
                    <span aria-hidden="true">⏱</span>
                    <?php echo e($readingMinutes); ?> min read
                </span>

                <span class="tb-article-meta-item">
                    <span aria-hidden="true">💬</span>

                    <?php echo e($commentCount); ?>

                    <?php echo e($commentCount === 1 ? 'comment' : 'comments'); ?>

                </span>

              
                    <span class="tb-article-meta-item tb-article-meta-updated">
                        Last updated:
                        <time datetime="<?php echo e(now()->toDateString()); ?>">
                            <?php echo e(now()->format('M d, Y')); ?>

                        </time>
                    </span>
              
            </div>

            <h1><?php echo e($post->title); ?></h1>

            <?php if(filled($post->intro)): ?>
                <p class="tb-article-intro">
                    <?php echo e(trim(strip_tags((string) $post->intro))); ?>

                </p>
            <?php endif; ?>

            <div class="tb-article-body">
                <?php $__currentLoopData = $contentBlocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$type, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(filled($value)): ?>
                        <?php if($type === 'image'): ?>
                            <?php
                                $inlineImage = $imageUrl($value);
                            ?>

                            <?php if($inlineImage): ?>
                                <figure class="tb-article-body-image">
                                    <img
                                        src="<?php echo e($inlineImage); ?>"
                                        alt="<?php echo e($post->title); ?>"
                                        loading="lazy"
                                        onerror="this.closest('figure').remove()"
                                    >
                                </figure>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="tb-article-rich-text">
                                <?php echo $value; ?>

                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>

            <p class="tb-article-source">
                <strong>Source:</strong>
                <a href="<?php echo e(route('home')); ?>">TrendyBeatz</a>
            </p>
        </article>


        

    <section class="tb-share-card">
        <p class="tb-share-heading">
            🔗 Share this Article with others on
        </p>

        <div class="tb-share-row">
            <button
                type="button"
                class="tb-share-copy"
                onclick="tbCopyPageLink(this)"
                aria-live="polite"
            >Copy Link</button>
            <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
                <a class="a2a_button_facebook"></a>
                <a class="a2a_button_x"></a>
                <a class="a2a_button_email"></a>
                <a class="a2a_button_pinterest"></a>
                <a class="a2a_button_linkedin"></a>
                <a class="a2a_button_whatsapp"></a>
            </div>

            
        </div>
    </section>

        <?php if($relatedPosts->isNotEmpty()): ?>
            <section class="tb-article-panel">
                <h2 class="tb-article-panel-heading">
                    📌 Related Posts
                </h2>

                <div class="tb-article-related-list">
                    <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $relatedPhoto = $imageUrl($related->photo);

                            $relatedDate = $related->updated_at
                                ? \Illuminate\Support\Carbon::parse(
                                    $related->updated_at
                                )
                                : null;

                            $relatedCategoryClass = $categoryClasses[
                                $related->category_slug
                            ] ?? 'tb-blog-news';
                        ?>

                        <a
                            class="tb-article-related-card"
                            href="<?php echo e(route('blogs.show', $related->slug)); ?>"
                        >
                            <span class="tb-article-related-image">
                                <span aria-hidden="true">TrendyBlog</span>

                                <?php if($relatedPhoto): ?>
                                    <img
                                        src="<?php echo e($relatedPhoto); ?>"
                                        alt="<?php echo e($related->title); ?>"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                <?php endif; ?>
                            </span>

                            <span class="tb-article-related-content">
                                <span
                                    class="tb-article-badge <?php echo e($relatedCategoryClass); ?>"
                                >
                                    <?php echo e($related->category_name ?: 'News'); ?>

                                </span>

                                <strong><?php echo e($related->title); ?></strong>

                                <small>
                                    <?php if($relatedDate): ?>
                                        <?php echo e($relatedDate->format('d M Y')); ?>

                                    <?php endif; ?>

                                    <?php if(filled($related->posted_by_name)): ?>
                                        ✍ <?php echo e($related->posted_by_name); ?>

                                    <?php endif; ?>
                                </small>

                                <span class="tb-article-related-read">
                                    Continue Reading →
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($post->category_slug): ?>
                    <a
                        class="tb-article-panel-more"
                        href="<?php echo e(route('blogs.category', $post->category_slug)); ?>"
                    >
                        View All <?php echo e($post->category_name); ?> Posts →
                    </a>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if($latestPosts->isNotEmpty()): ?>
            <section class="tb-article-panel">
                <h2 class="tb-article-panel-heading">
                    📰 Latest Posts
                </h2>

                <div class="tb-article-related-list">
                    <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $latestPhoto = $imageUrl($latest->photo);

                            $latestCategoryClass = $categoryClasses[
                                $latest->category_slug
                            ] ?? 'tb-blog-news';

                            $latestDate = filled($latest->updated_at)
                            ? \Illuminate\Support\Carbon::parse($latest->updated_at)
                            : null;
                        ?>

                        <a
                            class="tb-article-related-card"
                            href="<?php echo e(route('blogs.show', $latest->slug)); ?>"
                        >
                            <span class="tb-article-related-image">
                                <span aria-hidden="true">TrendyBlog</span>

                                <?php if($latestPhoto): ?>
                                    <img
                                        src="<?php echo e($latestPhoto); ?>"
                                        alt="<?php echo e($latest->title); ?>"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                <?php endif; ?>
                            </span>

                            <span class="tb-article-related-content">
                                <span
                                    class="tb-article-badge <?php echo e($latestCategoryClass); ?>"
                                >
                                    <?php echo e($latest->category_name ?: 'News'); ?>

                                </span>

                                <strong><?php echo e($latest->title); ?></strong>
                                <small>
                                    <?php if($latestDate): ?>
                                        <time datetime="<?php echo e($latestDate->toDateString()); ?>">
                                            <?php echo e($latestDate->format('d M Y')); ?>

                                        </time>
                                    <?php endif; ?>

                                    <?php if(filled($latest->posted_by_name)): ?>
                                        ✍ <?php echo e($latest->posted_by_name); ?>

                                    <?php endif; ?>
                                </small>

                                <span class="tb-article-related-read">
                                    Continue Reading →
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <a
                    class="tb-article-panel-more"
                    href="<?php echo e(route('blogs.index')); ?>"
                >
                    View More News &amp; Gists →
                </a>
            </section>
        <?php endif; ?>

        <section class="tb-article-panel">
            <h2 class="tb-article-panel-heading">
                📁 Browse Categories
            </h2>

            <div class="tb-article-category-footer">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('blogs.category', $category->slug)); ?>">
                        <?php echo e($category->name); ?> →
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <a class="tb-article-back" href="<?php echo e(route('blogs.index')); ?>">
            <strong>More News &amp; Gists</strong>
            <span>Catch up on all the latest entertainment</span>
            <em>View All Posts →</em>
        </a>
    </div>


    <?php echo $__env->make('partials.comments', [
        'postType' => 'blog',
        'postId' => $post->id,
        'postTitle' => $post->title,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/blog-details.blade.php ENDPATH**/ ?>