<?php
    $blogCategories = [
        1 => ['name' => 'Sports News', 'class' => 'tb-cat-sports-news'],
        2 => ['name' => 'Celebrity News', 'class' => 'tb-cat-celebrity-news'],
        6 => ['name' => 'Hot Topics', 'class' => 'tb-cat-hot-topics'],
        7 => ['name' => 'Net Worth', 'class' => 'tb-cat-net-worth'],
        8 => ['name' => 'Music Reviews', 'class' => 'tb-cat-music-reviews'],
    ];
?>

<section class="tb-home-blog-section" id="<?php echo e($id ?? 'latest-blog-news'); ?>">
    <h2 class="section-heading">📰 <?php echo e($heading ?? 'Latest Blog & News'); ?></h2>
    

    <div class="tb-home-blog-grid">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $category = $blogCategories[(int) $blog->category_id]
                    ?? ['name' => 'News', 'class' => 'tb-cat-news'];

                $photo = trim((string) $blog->photo);

                if ($photo === '') {
                    $imageUrl = null;
                } elseif (preg_match('~^https?://~i', $photo)) {
                    $imageUrl = $photo;
                } else {
                    $photoPath = ltrim($photo, '/');

                    if (!str_starts_with($photoPath, 'images/')) {
                        $photoPath = 'images/blog/' . basename($photoPath);
                    }

                    $imageUrl = asset($photoPath);
                }
            ?>

            <a
                class="tb-home-blog-post"
                href="<?php echo e(route('blogs.show', $blog->slug)); ?>"
            >
                <div class="tb-home-blog-thumb">
                    <span class="tb-home-blog-placeholder" aria-hidden="true">
                        <?php echo e($placeholder ?? 'TrendyNews'); ?>

                    </span>

                    <?php if($imageUrl): ?>
                        <img
                            src="<?php echo e($imageUrl); ?>"
                            alt="<?php echo e($blog->title); ?>"
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>
                </div>

                <div class="tb-home-blog-info">
                    <span class="tb-home-blog-category <?php echo e($category['class']); ?>">
                        <?php echo e($category['name']); ?>

                    </span>

                    <h3 class="tb-home-blog-title">
                        <?php echo e($blog->title); ?>

                    </h3>

                    <p class="tb-home-blog-intro">
                        <?php echo e(\Illuminate\Support\Str::limit(
                            trim(strip_tags($blog->intro)),
                            160
                        )); ?>

                    </p>

                    <div class="tb-home-blog-meta">
                        <time datetime="<?php echo e(date('Y-m-d', strtotime($blog->updated_at))); ?>">
                            <?php echo e(date('d M Y', strtotime($blog->updated_at))); ?>

                        </time>

                        <span class="tb-home-blog-read">
                            Continue Reading →
                        </span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-home-blog-empty">No blog posts available yet.</p>
        <?php endif; ?>
    </div>

    <?php if(!empty($more)): ?>
        <div class="tb-home-blog-more">
            <a class="tb-home-view-all" href="<?php echo e($more); ?>">
                View All <?php echo e($heading ?? 'Blog & News'); ?> →
            </a>
        </div>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/home/blogs.blade.php ENDPATH**/ ?>