

<?php
    $pageTitle = 'Music - Discover and Stream Latest Music | Legal Download';

    $pageDescription = 'Discover, Stream and Download All the Latest Naija Music mp3, Videos, Dj mix & Entertainment Gists';

    $pageKeywords = 'Latest Nigerian Musics and Video, trending, songs, discover music, download music, latest naija music mp3 videos download, latest naija music mp3 videos download';

    $canonicalUrl = route('music.download');
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('meta_keywords', $pageKeywords); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php $__env->startSection('content'); ?>
<section class="tb-download-page">

    <nav
        class="tb-download-quick-links"
        aria-label="Browse music sections"
    >
        <a href="<?php echo e(route('music.naija')); ?>">Naija Music <span>→</span></a>

        <a href="<?php echo e(route('music.ghana')); ?>">Ghanaian Music <span>→</span></a>

        <a href="<?php echo e(route('music.african')); ?>">African Music <span>→</span></a>

        <a href="<?php echo e(route('music.gospel')); ?>">Gospel Music <span>→</span></a>

        <a href="<?php echo e(route('music.highlife')); ?>">HighLife Music <span>→</span></a>

        <a href="<?php echo e(route('albums.popular')); ?>">Popular Albums <span>→</span></a>

        <a href="<?php echo e(route('blogs.category', 'music-reviews')); ?>">
            Music Reviews <span>→</span>
        </a>

        <a href="<?php echo e(route('songs.top_rated')); ?>">
            Top Rated Songs <span>→</span>
        </a>

        <a href="<?php echo e(route('songs.trending')); ?>">
            Top 10 Trending Songs <span>→</span>
        </a>

        <a href="<?php echo e(route('songs.week')); ?>">
            Top 10 Song Of The Week <span>→</span>
        </a>

        <a href="<?php echo e(route('songs.day')); ?>">
            Top 10 Song Of The Day
            (Songs Released Today) <span>→</span>
        </a>
    </nav>

    <p class="home-date">
        <time datetime="<?php echo e(now()->toDateString()); ?>">
            <?php echo e(now()->format('M d, Y')); ?>

        </time>
    </p>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'song-of-the-day',
        'heading' => 'Song of the Day',
        'badge' => 'Song of the Day',
        'items' => $day,
        'more' => route('songs.day'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section
        class="tb-download-albums"
        id="popular-albums"
    >
        <h2 class="sub-section-heading">
            Popular Albums
        </h2>

        <div class="tb-download-album-list">
            <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $cover = trim(
                        (string) $album->cover_url
                    );

                    if ($cover === '') {
                        $coverUrl = null;
                    } elseif (preg_match('~^https?://~i', $cover)) {
                        $coverUrl = $cover;
                    } else {
                        $coverPath = ltrim($cover, '/');

                        $coverUrl = asset(
                            str_starts_with($coverPath, 'images/')
                                ? $coverPath
                                : 'images/' . $coverPath
                        );
                    }
                ?>

                <a
                    class="tb-download-album"
                    href="<?php echo e(route('albums.index')); ?>"
                >
                    <span class="tb-download-album-cover">
                        <span
                            class="tb-download-album-placeholder"
                            aria-hidden="true"
                        >
                            TB
                        </span>

                        <?php if($coverUrl): ?>
                            <img
                                src="<?php echo e($coverUrl); ?>"
                                alt="<?php echo e($album->artist_name); ?> - <?php echo e($album->title); ?> album cover"
                                loading="lazy"
                                onerror="this.remove()"
                            >
                        <?php endif; ?>
                    </span>

                    <span class="tb-download-album-info">
                        <span class="tb-download-album-badge">
                            Album / EP
                        </span>

                        <strong class="tb-download-album-artist">
                            <?php echo e($album->artist_name); ?>

                        </strong>

                        <span class="tb-download-album-title">
                            <?php echo e($album->title); ?>

                        </span>

                        <?php if($album->released_year): ?>
                            <small>
                                Year of Release:
                                <?php echo e($album->released_year); ?>

                            </small>
                        <?php endif; ?>
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="tb-home-empty">
                    No published albums available yet.
                </p>
            <?php endif; ?>
        </div>

        <div class="tb-download-section-more">
            <a
                class="tb-home-view-all"
                href="<?php echo e(route('albums.index')); ?>"
            >
                Explore All Popular Albums →
            </a>
        </div>
    </section>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'latest-naija',
        'heading' => 'Latest Naija Songs',
        'badge' => 'Music',
        'items' => $naija,
        'more' => route('music.naija'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'latest-ghana',
        'heading' => 'Latest Ghana Songs',
        'badge' => 'Music',
        'items' => $ghana,
        'more' => route('music.ghana'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'latest-african',
        'heading' => 'Latest African Songs',
        'badge' => 'Music',
        'items' => $african,
        'more' => route('music.african'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'gospel-songs',
        'heading' => 'Gospel Songs',
        'badge' => 'Gospel Music',
        'items' => $gospel,
        'more' => route('music.gospel'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'highlife-songs',
        'heading' => 'HighLife Songs',
        'badge' => 'HighLife Music',
        'items' => $highlife,
        'more' => route('music.highlife'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'songs-of-the-week',
        'heading' => 'Top 10 Songs of the Week',
        'badge' => 'Song of the Week',
        'items' => $week,
        'more' => url('/songs-of-the-week'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/music-download.blade.php ENDPATH**/ ?>