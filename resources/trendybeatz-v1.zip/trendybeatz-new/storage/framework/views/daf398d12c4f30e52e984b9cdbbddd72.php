

<?php
    $pageTitle = 'Album Download - Download Latest Music Albums Mp3'
        . ' » TrendyBeatz';

    $pageDescription = 'Discover the latest Nigerian, Ghanaian and'
        . ' African music albums and EPs on TrendyBeatz. Browse album'
        . ' covers, release dates and tracklists, then explore songs'
        . ' from your favorite artists.';

    $baseUrl = route('albums.index');

    $canonicalUrl = $albums->currentPage() === 1
        ? $baseUrl
        : $albums->url($albums->currentPage());

    $firstCover = trim((string) (
        $albums->first()->cover_url ?? ''
    ));

    if ($firstCover === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $firstCover)) {
        $socialImage = $firstCover;
    } else {
        $coverPath = ltrim($firstCover, '/');

        $socialImage = asset(
            str_starts_with($coverPath, 'images/')
                ? $coverPath
                : 'images/' . $coverPath
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php if($albums->currentPage() > 1): ?>
    <?php $__env->startSection(
        'previous_url',
        $albums->currentPage() === 2
            ? $baseUrl
            : $albums->previousPageUrl()
    ); ?>
<?php endif; ?>

<?php if($albums->hasMorePages()): ?>
    <?php $__env->startSection('next_url', $albums->nextPageUrl()); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <section class="tb-day-page">
        <h1 class="section-heading">
            Download Latest Music Albums, Nigerian Music Albums,
            Ghana Music Albums, and African Albums
        </h1>

        <?php
            $currentDate = now();
        ?>

        <p class="tb-day-page-date">
            <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                <?php echo e($currentDate->format('M d, Y')); ?>

            </time>
        </p>

        <?php echo $__env->make('partials.home.albums', [
            'id' => 'all-artist-albums',
            'heading' => 'Latest Albums and EPs',
            'items' => $albums,
            'more' => null,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('partials.pagination', [
            'paginator' => $albums,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/albums.blade.php ENDPATH**/ ?>