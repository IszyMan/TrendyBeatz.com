

<?php $__env->startSection('title', 'Edit Listing'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Edit Listing #<?php echo e($listing->id); ?></h1>

        <a href="<?php echo e(route('admin.listings.index')); ?>">
            ← All Listings
        </a>
    </div>

    <?php echo $__env->make('admin.listings.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/listings/edit.blade.php ENDPATH**/ ?>