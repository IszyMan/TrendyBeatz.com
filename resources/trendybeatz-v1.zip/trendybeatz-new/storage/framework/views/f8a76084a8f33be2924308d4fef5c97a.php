

<?php
    /*
     * Metadata only. Values needed by the visible page
     * are calculated in the body below.
     */
    $artistName = $song->artist_name ?: 'TrendyBeatz';
    $trackTitle = trim((string) $song->TrackTitle);
    $featuring = trim((string) $song->Featuring);
    $fullTitle = $artistName . ' - ' . $trackTitle;
    if (
        $featuring !== ''
        && !preg_match('/\b(?:ft|feat|featuring)\.?\s/i', $trackTitle)
    ) {
        $fullTitle .= ' feat. ' . $featuring;
    }
    $pageTitle = $fullTitle . ' Music';

    $canonical = route('music_details', [
        $song->id,
        \App\Support\MusicUrl::slug($song),
    ]);

    $keywordTitle = $artistName . ' ' . $trackTitle;

    if (
        $featuring !== ''
        && !preg_match('/\b(?:ft|feat|featuring)\.?\s/i', $trackTitle)
    ) {
        $keywordTitle .= ' feat. ' . $featuring;
    }

    $metaKeywords = implode(', ', [
        $keywordTitle,
        'Download ' . $keywordTitle,
        'Stream ' . $trackTitle,
        'Download ' . $keywordTitle . ' song',
        'download music mp3 ' . $keywordTitle,
        'Download ' . $fullTitle,
        $keywordTitle . ' free mp3',
    ]);

    $metaDescription = collect([
        $song->introduction ?? '',
        $song->TrackInfo ?? '',
    ])
        ->map(fn ($text) => trim(strip_tags((string) $text)))
        ->filter(fn ($text) => $text !== '')
        ->implode(' ');

    if ($metaDescription === '') {
        $metaDescription = 'Discover and stream '
            . $fullTitle
            . ' on TrendyBeatz.';
    }

    $metaDescription = \Illuminate\Support\Str::limit(
        preg_replace('/\s+/u', ' ', $metaDescription),
        260,
        ''
    );

    $metaCover = trim((string) $song->CoverUrl);

    $artistSlug = \Illuminate\Support\Str::slug($artistName);

    $socialImage = $metaCover === ''
        ? null
        : (
            preg_match('~^https?://~i', $metaCover)
                ? $metaCover
                : asset(
                    str_starts_with(ltrim($metaCover, '/'), 'images/')
                        ? ltrim($metaCover, '/')
                        : 'images/' . ltrim($metaCover, '/')
                )
        );
?>

<?php $__env->startSection('title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('meta_keywords', $metaKeywords); ?>
<?php $__env->startSection('meta_description', $metaDescription); ?>
<?php $__env->startSection('canonical', $canonical); ?>
<?php $__env->startSection('social_title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('social_description', $metaDescription); ?>

<?php if($socialImage): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>


<article class="tb-music-detail tb-music-detail-primary">

    <header class="tb-music-detail-header">
        <h1><?php echo e($pageTitle); ?></h1>

        <div class="tb-music-detail-cover">
            <span class="tb-music-detail-placeholder" aria-hidden="true">
                TB
            </span>

            <?php if($socialImage): ?>
                <img
                    src="<?php echo e($socialImage); ?>"
                    alt="<?php echo e($fullTitle); ?> cover art"
                    onerror="this.remove()"
                >
            <?php endif; ?>
        </div>

        <p class="tb-music-detail-posted">
            Posted By:
            <strong>
                <a
                    class="tb-music-detail-poster-link"
                    href="<?php echo e(route('songs.posted_by', [
                        'slug' => \Illuminate\Support\Str::slug($song->posted_by_name),
                    ])); ?>"
                >
                    <?php echo e($song->posted_by_name); ?>

                </a>
            </strong>

            <?php
                $currentTime = now();
            ?>

            <span aria-hidden="true">•</span>

            <time datetime="<?php echo e($currentTime->toIso8601String()); ?>">
                <?php echo e($currentTime->format('M d, Y ')); ?>

            </time>
        </p>
    </header>

    <!--<div class="tb-music-detail-ad-label">
        Advertisement
    </div>-->

    <section class="tb-music-detail-section">
        <h2 class="tb-music-detail-heading">
            Track Details
        </h2>

        <div class="tb-music-detail-facts">
            <p>
                <strong>Artist Name:</strong>
                <a
                    class="tb-music-detail-blue"
                    href="<?php echo e(route('artists.show', $artistSlug)); ?>"
                    style="text-decoration: none;"
                >
                    <?php echo e($artistName); ?>

                </a>
            </p>

            <p>
                <strong>Track Title:</strong>
                <span class="tb-music-detail-red">
                    <?php echo e($trackTitle); ?>

                </span>
            </p>

            <?php if($featuredArtists->isNotEmpty()): ?>
                <p>
                    <strong>Featuring:</strong>

                    <?php $__currentLoopData = $featuredArtists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredArtist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->first): ?>
                            <span aria-hidden="true">, </span>
                        <?php endif; ?>

                        <a
                            class="tb-music-detail-red"
                            href="<?php echo e(!empty($featuredArtist['slug'])
                                ? route('artists.show', $featuredArtist['slug'])
                                : route('artists.index')); ?>"
                            style="text-decoration: none;"
                        >
                            <?php echo e($featuredArtist['name']); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            <?php endif; ?>

            <?php if(trim((string) $song->YearOfRelease) !== ''): ?>
                <p>
                    <strong>Recorded:</strong>
                    <a
                        class="tb-music-detail-green tb-music-detail-year-link"
                        href="<?php echo e(route('music.year', $song->YearOfRelease)); ?>"
                    >
                        <?php echo e($song->YearOfRelease); ?> Music
                    </a>
                </p>
            <?php endif; ?>

            <?php if(trim((string) $song->country_id) !== ''): ?>
                <p>
                    <strong>Country:</strong>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('music.' . $song->country_id)); ?>"
                        style="text-decoration: none;"
                    >
                        <?php echo e(ucfirst($song->country_id)); ?> Music
                    </a>
                </p>
            <?php endif; ?>

            <?php if(!empty($song->album_id) && trim((string) $song->album_name) !== ''): ?>
                <p>
                    <strong>Album Name:</strong>
                    <a
                        class="tb-music-detail-red"
                        href="<?php echo e(\App\Support\AlbumUrl::detail($song)); ?>"
                        style="text-decoration: none;"
                    >
                        <?php echo e($song->album_name); ?>

                    </a>
                </p>
            <?php endif; ?>

          <p>
                <strong>Category:</strong>

                <?php if((int) ($song->isgospel ?? 0) === 1): ?>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('music.gospel')); ?>"
                        style="text-decoration: none;"
                    >
                        Gospel Songs
                    </a>
                <?php elseif((int) ($song->ishighlife ?? 0) === 1): ?>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('music.highlife')); ?>"
                        style="text-decoration: none;"
                    >
                        Highlife Music
                    </a>
                <?php else: ?>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('music.all')); ?>"
                        style="text-decoration: none;"
                    >
                        Latest Music
                    </a>
                <?php endif; ?>
            </p>
        </div>
    </section>

    <!--<div class="tb-music-detail-ad-label">
        Advertisement
    </div>-->

    <?php
        $introduction = trim(strip_tags(
            (string) $song->introduction
        ));

        $descriptionParagraphs = array_filter(
            [
                trim(strip_tags((string) $song->TrackInfo)),
                trim(strip_tags((string) $song->trackinfo1)),
                trim(strip_tags((string) $song->trackinfo2)),
            ],
            fn ($text) => $text !== ''
        );
    ?>

    <?php if($introduction !== '' || $descriptionParagraphs !== []): ?>
        <section class="tb-music-detail-section">
            <h2 class="tb-music-detail-heading">
                About This Song
            </h2>

            <div class="tb-music-detail-description">
                <?php if($introduction !== ''): ?>
                    <p class="tb-music-detail-introduction">
                        <?php echo e($introduction); ?>

                    </p>
                <?php endif; ?>

                <?php $__currentLoopData = $descriptionParagraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($paragraph); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
        $trackPath = trim((string) $song->TrackUrl);

        $trackUrl = $trackPath === ''
            ? null
            : (
                preg_match('~^https?://~i', $trackPath)
                    ? $trackPath
                    : asset(ltrim($trackPath, '/'))
            );

        $digitalStore = trim((string) $song->buy_song);

        $digitalStoreUrl = filter_var(
            $digitalStore,
            FILTER_VALIDATE_URL
        ) && in_array(
            parse_url($digitalStore, PHP_URL_SCHEME),
            ['http', 'https'],
            true
        ) ? $digitalStore : null;

        /*
         * The restored listing table contains scriptUrl.
         * Extract recognized media URLs; do not print
         * scriptUrl directly as executable HTML.
         */
        $embedSource = (string) $song->scriptUrl;

        $youtubeEmbed = trim((string) ($song->youtube_embed_url ?? ''));
        $audiomackEmbed = trim((string) ($song->audiomack_embed_url ?? ''));
    ?>

  
        <?php if($youtubeEmbed || $audiomackEmbed || $digitalStoreUrl || $hasAudioFile): ?>
            <section class="tb-music-detail-listening">

                
                <?php if($youtubeEmbed || $audiomackEmbed): ?>
                    <h2>
                        Stream <?php echo e($fullTitle); ?> legally on TrendyBeatz.com
                    </h2>

                    <?php if($youtubeEmbed): ?>
                        <div class="tb-music-detail-youtube">
                            <iframe
                                src="<?php echo e($youtubeEmbed); ?>"
                                title="<?php echo e($fullTitle); ?> on YouTube"
                                loading="lazy"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen
                            ></iframe>
                        </div>
                    <?php endif; ?>

                      <br>
                    <h2>Stream <?php echo e($fullTitle); ?> on Audiomack</h2>

                    <?php if($audiomackEmbed): ?>
                        <div class="tb-music-detail-audiomack">
                            <iframe
                                src="<?php echo e($audiomackEmbed); ?>"
                                title="<?php echo e($fullTitle); ?> on Audiomack"
                                loading="lazy"
                                allow="autoplay"
                            ></iframe>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                
                <?php if($digitalStoreUrl): ?>
                    <div class="tb-music-detail-digital">
                        <h2>
                            Stream <?php echo e($fullTitle); ?> on Digital Store
                        </h2>

                        <a
                            class="tb-music-detail-store"
                            href="<?php echo e($digitalStoreUrl); ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            Stream <?php echo e($fullTitle); ?>

                        </a>
                    </div>
                <?php endif; ?>

                
                <?php if($hasAudioFile): ?>
                    <div class="tb-music-detail-audio">
                        <h2>Listen and Download <?php echo e($fullTitle); ?> Mp3</h2>

                        <p class="tb-music-copyright-notice">
                            <strong>Copyright Notice:</strong>
                            This song and its audio materials were published upon
                            express request and direct permission from the
                            copyright holder.
                        </p>

                        <audio controls preload="none">
                            <source src="<?php echo e($trackUrl); ?>">
                            Your browser does not support audio playback.
                        </audio>

                        <a
                            class="tb-music-detail-download"
                            href="<?php echo e($trackUrl); ?>"
                            download
                        >
                            Download <?php echo e($fullTitle); ?> Mp3
                        </a>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
  

</article>



<section class="tb-share-card">
    <p class="tb-share-heading">
        🔗 Share <?php echo e($fullTitle); ?> Music with others on
    </p>

    <div class="tb-share-row">
        <button
            type="button"
            class="tb-share-copy"
            onclick="tbCopyPageLink(this)"
            aria-live="polite"
        >Copy Link</button>
        <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
            <a class="a2a_button_facebook"></a>
            <a class="a2a_button_x"></a>
            <a class="a2a_button_email"></a>
            <a class="a2a_button_pinterest"></a>
            <a class="a2a_button_linkedin"></a>
            <a class="a2a_button_whatsapp"></a>
        </div>

        
    </div>
</section>


<aside class="tb-music-detail tb-music-detail-related">

    <?php if($artistSongs->isNotEmpty()): ?>
        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                Discover <?php echo e($artistName); ?> Other Songs
            </h2>

            <div class="tb-music-detail-discovery-list">
                <?php $__currentLoopData = $artistSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $featuring = trim((string) (
                        $related->featuring ?? $related->Featuring ?? ''
                    ));
                ?>
                    <a href="<?php echo e(\App\Support\MusicUrl::detail($related)); ?>">
                        <span
                            class="tb-music-detail-icon"
                            aria-hidden="true"
                        >♫</span>

                        <span class="tb-music-detail-discovery-text">
                            <strong>
                                <?php echo e($related->artist_name); ?>

                                - <?php echo e($related->track_title); ?>

                            </strong>

                            <span>
                                 <b>   <?php if(filled($related->featuring)): ?>
                                        feat. <?php echo e($related->featuring); ?>

                                    <?php endif; ?>
                                </b>
                            </span>

                            <small>Tap to Stream</small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
                <a
                    class="tb-home-view-all"
                    href="<?php echo e(route('artists.show', $artistSlug)); ?>"
                >
                    View All <?php echo e($artistName); ?> Songs →
                </a>

    <?php if($artistVideos->isNotEmpty()): ?>
    <section class="tb-music-detail-discovery">
        <h2 class="tb-music-detail-heading">
            Discover &amp; Watch <?php echo e($artistName); ?> Videos
        </h2>

        <div class="tb-music-detail-discovery-list">
            <?php $__currentLoopData = $artistVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $featuring = trim((string) (
                        $video->featuring
                        ?? $video->Featuring
                        ?? ''
                    ));
                ?>

                <a
                    class="tb-home-song tb-home-video"
                    href="<?php echo e(\App\Support\VideoUrl::detail($video)); ?>"
                >
                    <span
                        class="tb-music-detail-icon"
                        aria-hidden="true"
                    >▶</span>

                    <span class="tb-music-detail-discovery-text">
                        <strong>
                            <?php echo e($artistName); ?>

                            - <?php echo e($video->track_title); ?>

                        </strong>

                       <b> <?php if($featuring !== ''): ?>
                            <span>feat. <?php echo e($featuring); ?></span>
                            <?php endif; ?>
                        </b>

                            <small>Watch video</small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if($artistAlbums->isNotEmpty()): ?>
        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                <?php echo e($artistName); ?> Music Albums
            </h2>

            <div class="tb-music-detail-discovery-list">
                <?php $__currentLoopData = $artistAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(\App\Support\AlbumUrl::detail($album)); ?>">
                        <span
                            class="tb-music-detail-icon"
                            aria-hidden="true"
                        >♫</span>

                        <span class="tb-music-detail-discovery-text">
                            <strong>
                                → <?php echo e($album->title); ?>


                                <?php if($album->released_year): ?>
                                    Album Released in
                                    <?php echo e($album->released_year); ?>

                                <?php endif; ?>
                            </strong>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if($collaborations->isNotEmpty()): ?>
        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                Discover and Stream
                <?php echo e($artistName); ?> Various Collaborations
            </h2>

            <div class="tb-music-detail-discovery-list">
                <?php $__currentLoopData = $collaborations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $featuring = trim((string) (
                            $related->featuring
                            ?? $related->Featuring
                            ?? ''
                        ));
                    ?>

                    <a href="<?php echo e(\App\Support\MusicUrl::detail($related)); ?>">
                        <span
                            class="tb-music-detail-icon"
                            aria-hidden="true"
                        >♫</span>

                        <span class="tb-music-detail-discovery-text">
                            <strong>
                                <?php echo e($related->artist_name); ?>

                                - <?php echo e($related->track_title); ?>

                            </strong>

                           <b> <?php if($featuring !== ''): ?>
                                <span>feat. <?php echo e($featuring); ?></span>
                            <?php endif; ?>
                            </b>

                            <small>Tap to Stream</small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if($latestMusic->isNotEmpty()): ?>
        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                Discover and Stream Latest Music
                &amp; Videos Below
            </h2>

            <div class="tb-music-detail-discovery-list">
                <?php $__currentLoopData = $latestMusic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isVideo = strtolower(
                            (string) $related->listing_type
                        ) === 'video';

                        $featuring = trim((string) (
                            $related->featuring
                            ?? $related->Featuring
                            ?? ''
                        ));
                    ?>

                    <a href="<?php echo e($isVideo
                        ? route('videos.index')
                        : \App\Support\MusicUrl::detail($related)); ?>">
                        <span
                            class="tb-music-detail-icon"
                            aria-hidden="true"
                        >
                            <?php echo e($isVideo ? '▶' : '♫'); ?>

                        </span>

                        <span class="tb-music-detail-discovery-text">
                            <strong>
                                <?php echo e($related->artist_name); ?>

                                - <?php echo e($related->track_title); ?>

                            </strong>

                           <b> <?php if($featuring !== ''): ?>
                                <span>feat. <?php echo e($featuring); ?></span>
                            <?php endif; ?></b>

                            <small>
                                <?php echo e($isVideo
                                    ? 'Watch Video'
                                    : 'Tap to Stream'); ?>

                            </small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

   
        <a class="tb-home-view-all" href="<?php echo e(route('music.all')); ?>">
            Click Here for more Music on TrendyBeatz.com →
        </a>
       

</aside>




    <?php echo $__env->make('partials.comments', [
        'postType' => 'music',
        'postId' => $song->id,
        'postTitle' => $fullTitle,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/music-details.blade.php ENDPATH**/ ?>