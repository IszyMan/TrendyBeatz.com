<?php
    $editing = $artist !== null;
?>

<form
    class="admin-panel admin-form-grid"
    method="POST"
    enctype="multipart/form-data"
    action="<?php echo e($editing
        ? route('admin.artists.update', $artist->id)
        : route('admin.artists.store')); ?>"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>

        <p class="admin-field-wide">
            <strong>Artist ID:</strong>
            <?php echo e($artist->artist_id); ?>

        </p>
    <?php endif; ?>

    <?php $__currentLoopData = [
        'Stage_Name' => 'Stage name',
        'Fullname' => 'Full name',
        'RecordLabel' => 'Record label',
        'Genres' => 'Genres',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="admin-field">
            <?php echo e($label); ?>


            <input
                type="text"
                name="<?php echo e($field); ?>"
                maxlength="191"
                value="<?php echo e(old($field, $artist->{$field} ?? '')); ?>"
                <?php if($field === 'Stage_Name'): echo 'required'; endif; ?>
            >
        </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <label class="admin-field">
        Country

        <select name="country_id" required>
            <?php $__currentLoopData = [
                'naija' => 'Naija',
                'ghana' => 'Ghana',
                'african' => 'African',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($value); ?>"
                    <?php if(
                        old('country_id', $artist->country_key ?? 'naija')
                            === $value
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <!--<label class="admin-field">
        Artist category ID

        <input
            type="number"
            name="category_id"
            min="0"
            max="2147483647"
            required
            value="<?php echo e(old('category_id', $artist->category_id ?? '')); ?>"
        >
    </label>

    <label class="admin-field">
        Display order

        <input
            type="number"
            name="order_id"
            min="0"
            max="2147483647"
            required
            value="<?php echo e(old('order_id', $artist->order_id ?? '')); ?>"
        >
    </label>-->

    <label class="admin-field">
        Net worth ID

        <input
            type="number"
            name="networth_id"
            min="0"
            max="2147483647"
            value="<?php echo e(old('networth_id', $artist->networth_id ?? '')); ?>"
        >
    </label>

    <label class="admin-field">
        Also comedian?

        <select name="Is_also_comedian" required>
            <option
                value="0"
                <?php if(
                    (string) old(
                        'Is_also_comedian',
                        $artist->Is_also_comedian ?? 0
                    ) === '0'
                ): echo 'selected'; endif; ?>
            >
                No
            </option>

            <option
                value="1"
                <?php if(
                    (string) old(
                        'Is_also_comedian',
                        $artist->Is_also_comedian ?? 0
                    ) === '1'
                ): echo 'selected'; endif; ?>
            >
                Yes
            </option>
        </select>
    </label>

    <label class="admin-field admin-field-wide">
        Artist biography

        <textarea
            name="Place_Birth"
            rows="10"
            placeholder="Write the artist biography..."
        ><?php echo e(old('Place_Birth', $artist->Place_Birth ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Profile image

        <input
            type="file"
            name="profile_image"
            accept="image/jpeg,image/png,image/webp,image/gif"
        >

        <?php if($editing && filled($artist->img)): ?>
            <small>Current image: <?php echo e($artist->img); ?></small>
        <?php endif; ?>
    </label>

    <input type="hidden" name="IsPublished" value="NO">

    <div class="admin-checks admin-field-wide">
        <label>
            <input
                type="checkbox"
                name="IsPublished"
                value="YES"
                <?php if(
                    old('IsPublished', $artist->IsPublished ?? 'NO') === 'YES'
                ): echo 'checked'; endif; ?>
            >

            Published
        </label>
    </div>

    <div class="admin-field-wide">
        <button class="admin-button" type="submit">
            <?php echo e($editing ? 'Save Changes' : 'Create Artist'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/artists/form.blade.php ENDPATH**/ ?>