<section class="tb-home-section tb-home-songs" id="<?php echo e($id); ?>">
    <h2 class="sub-section-heading"><?php echo e($heading); ?></h2>

    <div class="tb-home-song-list">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a
                class="tb-home-song"
                href="<?php echo e(\App\Support\MusicUrl::detail($song)); ?>"
            >
                <?php
                    $cover = trim((string) $song->cover_url);

                    if ($cover === '') {
                        $coverUrl = null;
                    } elseif (preg_match('~^https?://~i', $cover)) {
                        $coverUrl = $cover;
                    } else {
                        $path = ltrim($cover, '/');

                        // Handles both "cover.jpg" and "images/cover.jpg".
                        $coverUrl = asset(
                            str_starts_with($path, 'images/')
                                ? $path
                                : 'images/' . $path
                        );
                    }
                ?>

                <span class="tb-home-song-thumb">
                    <span class="tb-home-song-placeholder" aria-hidden="true">
                        TB
                    </span>

                    <?php if($coverUrl): ?>
                        <img
                            src="<?php echo e($coverUrl); ?>"
                            alt="<?php echo e($song->artist_name ?: 'TrendyBeatz'); ?> – <?php echo e($song->track_title); ?> cover"
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>
                </span>

                <span class="tb-home-song-info">
                    <span class="tb-home-song-badge">
                        <?php echo e($badge); ?>

                    </span>

                    <strong class="tb-home-song-artist">
                        <?php echo e($song->artist_name ?: 'TrendyBeatz'); ?>

                    </strong>

                    <span class="tb-home-song-title">
                        <?php echo e($song->track_title); ?>

                    </span>

                    <?php if($song->featuring): ?>
                        <span class="tb-home-song-featuring">
                            Featuring <?php echo e($song->featuring); ?>

                        </span>
                    <?php endif; ?>

                    <span class="tb-home-song-actions">
                        <span class="tb-home-discover">Discover</span>
                        <span class="tb-home-action-divider">|</span>
                        <span class="tb-home-stream">Stream</span>
                    </span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-home-empty">
                No songs in this section yet.
            </p>
        <?php endif; ?>
    </div>

    <?php if(!empty($more)): ?>
        <a class="tb-home-view-all" href="<?php echo e($more); ?>">
            View All <?php echo e($heading); ?> →
        </a>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/home/songs.blade.php ENDPATH**/ ?>