<?php
    $articleUrl = route('blogs.show', $post->slug);

    $photo = trim((string) $post->photo);

    if ($photo === '') {
        $photoUrl = null;
    } elseif (preg_match('~^https?://~i', $photo)) {
        $photoUrl = $photo;
    } else {
        $photoPath = ltrim($photo, '/');

        $photoUrl = asset(
            str_starts_with($photoPath, 'images/')
                ? $photoPath
                : 'images/blog/' . basename($photoPath)
        );
    }

    $categoryClasses = [
        'sport-news' => 'tb-blog-sport',
        'celebrity-news' => 'tb-blog-celebrity',
        'hot-gists' => 'tb-blog-gists',
        'networth' => 'tb-blog-networth',
        'music-reviews' => 'tb-blog-reviews',
        'education' => 'tb-blog-education',
        'articles' => 'tb-blog-articles',
        'news' => 'tb-blog-news',
    ];

    $categoryClass = $categoryClasses[$post->category_slug]
        ?? 'tb-blog-news';

    $postedAt = $post->updated_at
        ? \Illuminate\Support\Carbon::parse($post->updated_at)
        : null;

    $intro = \Illuminate\Support\Str::limit(
        trim(strip_tags((string) $post->intro)),
        180,
        '...'
    );
?>

<a
    class="tb-news-card"
    href="<?php echo e($articleUrl); ?>"
    aria-label="Read <?php echo e($post->title); ?>"
>
    <span class="tb-news-card-image">
        <span class="tb-news-card-placeholder" aria-hidden="true">
            TrendyBlog
        </span>

        <?php if($photoUrl): ?>
            <img
                src="<?php echo e($photoUrl); ?>"
                alt="<?php echo e($post->title); ?> cover"
                loading="lazy"
                onerror="this.remove()"
            >
        <?php endif; ?>
    </span>

    <span class="tb-news-card-content">
        <span class="tb-blog-badge <?php echo e($categoryClass); ?>">
            <?php echo e($post->category_name ?: 'Music News'); ?>

        </span>

        <span class="tb-news-card-title">
            <?php echo e($post->title); ?>

        </span>

        <?php if($intro !== ''): ?>
            <span class="tb-news-card-intro">
                <?php echo e($intro); ?>

            </span>
        <?php endif; ?>

        <span class="tb-news-card-bottom">
            <span class="tb-news-card-meta">
                <?php if(filled($post->posted_by_name)): ?>
                    <span>
                        Posted by:
                        <strong><?php echo e($post->posted_by_name); ?></strong>
                    </span>
                <?php endif; ?>

                <?php if($postedAt): ?>
                    <time datetime="<?php echo e($postedAt->toDateString()); ?>">
                        <?php echo e($postedAt->format('M d, Y')); ?>

                    </time>
                <?php endif; ?>
            </span>

            <span class="tb-news-card-read">
                Continue Reading →
            </span>
        </span>
    </span>
</a><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/blogs/card.blade.php ENDPATH**/ ?>