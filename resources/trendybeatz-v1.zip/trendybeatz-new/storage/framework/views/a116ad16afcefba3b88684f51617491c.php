

<?php $__env->startSection('title', 'All Listings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All Listings</h1>

        <a
            class="admin-button"
            href="<?php echo e(route('admin.listings.create')); ?>"
        >
            + Add Listing
        </a>
    </div>

    <div class="admin-panel">
        <form
            class="admin-filters"
            method="GET"
            action="<?php echo e(route('admin.listings.index')); ?>"
        >
            <label class="admin-field">
                Search

                <input
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    placeholder="ID, title or artist"
                >
            </label>

            <label class="admin-field">
                Type

                <select name="type">
                    <option value="">All types</option>

                    <option value="Audio" <?php if($type === 'Audio'): echo 'selected'; endif; ?>>
                        Audio
                    </option>

                    <option value="video" <?php if($type === 'video'): echo 'selected'; endif; ?>>
                        Video
                    </option>
                </select>
            </label>

            <button class="admin-button" type="submit">
                Filter
            </button>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title / Artist</th>
                        <th>Type</th>
                        <th>Country</th>
                        <th>Published</th>
                        <th>Posted by</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($listing->id); ?></td>

                            <td>
                                <strong><?php echo e($listing->artist_name); ?></strong>
                                <br>
                                <?php echo e($listing->TrackTitle); ?>

                            </td>

                            <td><?php echo e($listing->ListingType); ?></td>
                            <td><?php echo e(ucfirst($listing->country_id)); ?></td>
                            <td><?php echo e($listing->IsPublished); ?></td>
                            <td><?php echo e($listing->posted_by_name ?: '—'); ?></td>

                            <td>
                                <?php echo e($listing->created_at
                                    ? \Illuminate\Support\Carbon::parse(
                                        $listing->created_at
                                    )->format('M d, Y')
                                    : '—'); ?>

                            </td>

                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route(
                                            'admin.listings.edit',
                                            $listing->id
                                        )); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>
                                        <form
                                            method="POST"
                                            action="<?php echo e(route(
                                                'admin.listings.destroy',
                                                $listing->id
                                            )); ?>"
                                            onsubmit="return confirm('Delete this listing?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-button admin-button-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">
                                No listings found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', [
                'paginator' => $listings,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/listings/index.blade.php ENDPATH**/ ?>