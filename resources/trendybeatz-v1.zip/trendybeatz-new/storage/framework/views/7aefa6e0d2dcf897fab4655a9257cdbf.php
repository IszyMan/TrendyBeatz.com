<section class="tb-home-albums" id="<?php echo e($id ?? 'latest-albums'); ?>">
    <h2 class="section-heading">
        <?php echo e($heading ?? 'Latest Albums'); ?>

    </h2>

    <div class="tb-home-album-list">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $cover = trim((string) $album->cover_url);

                if ($cover === '') {
                    $coverUrl = null;
                } elseif (preg_match('~^https?://~i', $cover)) {
                    $coverUrl = $cover;
                } else {
                    $coverPath = ltrim($cover, '/');

                    $coverUrl = asset(
                        str_starts_with($coverPath, 'images/')
                            ? $coverPath
                            : 'images/' . $coverPath
                    );
                }

                $displayTitle = trim(
                    ($album->artist_name ? $album->artist_name . ' - ' : '')
                    . $album->title
                );

                
            ?>

            <a
                class="tb-home-album-card"
                href="<?php echo e(\App\Support\AlbumUrl::detail($album)); ?>"
            >
                <span class="tb-home-album-cover">
                    <span class="tb-home-album-placeholder" aria-hidden="true">
                        TrendyAlbum
                    </span>

                    <?php if($coverUrl): ?>
                        <img
                            src="<?php echo e($coverUrl); ?>"
                            alt="<?php echo e($displayTitle); ?> cover"
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>
                </span>

                <span class="tb-home-album-info">
                    <span class="tb-home-album-badge">Album</span>

                    <strong class="tb-home-album-title">
                        <?php echo e($displayTitle); ?>

                    </strong>

                    <span class="tb-home-album-meta">
                        Tracklists: <?php echo e($album->track_count); ?>

                    </span>

                    <span class="tb-home-album-meta">
                        Year of Release: <?php echo e($album->released_year); ?>

                    </span>

                    <?php if($album->released_date): ?>
                        <span class="tb-home-album-meta">
                            Date Released:
                            <?php echo e(\Illuminate\Support\Carbon::parse(
                                $album->released_date
                            )->format('M d, Y')); ?>

                        </span>
                    <?php endif; ?>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-home-album-empty">
                No albums available yet.
            </p>
        <?php endif; ?>
    </div>

    <?php if(!empty($more)): ?>
        <div class="tb-home-album-more">
            <a class="tb-home-view-all" href="<?php echo e($more); ?>">
                View All Latest Albums →
            </a>
        </div>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/home/albums.blade.php ENDPATH**/ ?>