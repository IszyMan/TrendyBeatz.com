

<?php
    $pageTitle = $query !== ''
        ? 'Search results for ' . $query . ' — TrendyBeatz'
        : 'Search Music, Videos, Albums and More — TrendyBeatz';

    $description = 'Search TrendyBeatz for songs, videos, DJ mixes, albums, blog posts, artists and DJs.';

    $types = [
        'all' => 'All Results',
        'music' => 'Music',
        'video' => 'Video',
        'mix' => 'Mix',
        'album' => 'Album',
        'blog' => 'Blog',
        'artist' => 'Artists',
        'dj' => 'DJ',
    ];
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $description); ?>
<?php $__env->startSection('meta_keywords', 'TrendyBeatz search, music, videos, DJ mixes, albums, artists, DJs, blogs'); ?>
<?php $__env->startSection('canonical', request()->fullUrl()); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $description); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .tb-search-page {
            max-width: 960px;
            margin: 24px auto;
            padding: 0 16px;
            color: #25332b;
        }

        .tb-search-page * {
            box-sizing: border-box;
        }

        .tb-search-heading {
            margin: 0 0 20px;
            padding-bottom: 12px;
            border-bottom: 3px solid #198754;
            font-size: 28px;
            line-height: 1.3;
        }

        .tb-search-form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 12px;
        }

        .tb-search-input {
            flex: 1 1 250px;
            min-width: 0;
        }

        .tb-search-input,
        .tb-search-select {
            padding: 12px 14px;
            border: 1px solid #ccd7cf;
            border-radius: 5px;
            background: #fff;
            color: #222;
            font: inherit;
        }

        .tb-search-input:focus,
        .tb-search-select:focus {
            outline: 2px solid #198754;
            outline-offset: 2px;
        }

        .tb-search-button {
            padding: 12px 20px;
            border: 0;
            border-radius: 5px;
            background: #198754;
            color: #fff;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
        }

        .tb-search-button:hover {
            background: #146c43;
        }

        .tb-search-help,
        .tb-search-summary {
            font-size: 14px;
            line-height: 1.7;
            color: #647168;
        }

        .tb-search-summary {
            margin: 22px 0 14px;
        }

        .tb-search-results {
            display: grid;
            gap: 12px;
        }

        .tb-search-result {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 14px;
            border: 1px solid #e0e6e2;
            border-radius: 6px;
            background: #fff;
            color: #25332b;
            text-decoration: none;
        }

        .tb-search-result:hover {
            border-color: #198754;
            background: #f7faf8;
        }

        .tb-search-result:focus-visible {
            outline: 3px solid #198754;
            outline-offset: 3px;
        }

        .tb-search-cover {
            position: relative;
            display: grid;
            place-items: center;
            flex: 0 0 82px;
            width: 82px;
            height: 82px;
            overflow: hidden;
            border-radius: 5px;
            background: #edf3ef;
            color: #198754;
            font-size: 13px;
            font-weight: 800;
        }

        .tb-search-cover img {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .tb-search-info {
            flex: 1;
            min-width: 0;
        }

        .tb-search-badge {
            display: inline-block;
            margin-bottom: 7px;
            padding: 4px 10px;
            border-radius: 4px;
            color: #fff;
            font-size: 11px;
            font-weight: 800;
            line-height: 1.5;
        }

        /* Music — green */
        .tb-search-badge-music {
            background: #157347;
        }

        /* Video — blue */
        .tb-search-badge-video {
            background: #2457c5;
        }

        /* Mix — purple */
        .tb-search-badge-mix {
            background: #7636ad;
        }

        /* Album — brown-orange */
        .tb-search-badge-album {
            background: #a65310;
        }

        /* Blog — teal */
        .tb-search-badge-blog {
            background: #087780;
        }

        /* Artists — pink */
        .tb-search-badge-artist {
            background: #b52968;
        }

        /* DJ — red */
        .tb-search-badge-dj {
            background: #bd3030;
        }

        .tb-search-title {
            display: block;
            font-size: 16px;
            font-weight: 700;
            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .tb-search-date {
            display: block;
            margin-top: 6px;
            color: #758078;
            font-size: 12px;
        }

        .tb-search-empty {
            margin-top: 22px;
            padding: 22px;
            border: 1px solid #dce8df;
            border-radius: 6px;
            background: #f3f8f5;
            font-size: 15px;
            line-height: 1.8;
        }

        .tb-search-error {
            color: #b42318;
            font-size: 14px;
        }

        .tb-search-label {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
        }

        .tb-search-artist {
            display: block;
            margin-bottom: 4px;
            color: #14251b;
            font-size: 16px;
            font-weight: 800;
            line-height: 1.4;
            overflow-wrap: anywhere;
        }

        .tb-search-track {
            display: block;
            color: #526158;
            font-size: 14px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        @media (max-width: 600px) {
            .tb-search-artist {
                font-size: 15px;
            }

            .tb-search-track {
                font-size: 13px;
            }
        }

        @media (max-width: 600px) {
            .tb-search-page {
                padding: 0 12px;
            }

            .tb-search-heading {
                font-size: 24px;
            }

            .tb-search-input {
                flex-basis: 100%;
            }

            .tb-search-select {
                flex: 1;
                min-width: 0;
            }

            .tb-search-result {
                gap: 12px;
                padding: 12px;
            }

            .tb-search-cover {
                flex-basis: 65px;
                width: 65px;
                height: 65px;
            }

            .tb-search-title {
                font-size: 14px;
            }
        }
    </style>

    <section class="tb-search-page">
      

        <?php $__errorArgs = ['q'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="tb-search-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="tb-search-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if($results): ?>
            <p class="tb-music-detail-heading">
                <?php echo e(number_format($results->total())); ?>

                <?php echo e($results->total() === 1 ? 'result' : 'results'); ?>

                for <strong> “<?php echo e($query); ?>”</strong>
            </p>

            <div class="tb-search-results">
                <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $hasArtist = in_array(
                            $result->type,
                            ['music', 'video', 'mix', 'album'],
                            true
                        );

                        $resultTitle = trim((string) $result->title);
                        $featuring = trim((string) $result->featuring);

                        if (
                            $hasArtist
                            && $featuring !== ''
                            && !preg_match(
                                '/\b(?:ft|feat|featuring)\.?\s/i',
                                $resultTitle
                            )
                        ) {
                            $resultTitle .= ' feat. ' . $featuring;
                        }
                    ?>

                    <a class="tb-search-result" href="<?php echo e($result->url); ?>">
                        <span class="tb-search-cover">
                            <span aria-hidden="true">
                                <?php echo e($types[$result->type]); ?>

                            </span>

                            <?php if($result->image_url): ?>
                                <img
                                    src="<?php echo e($result->image_url); ?>"
                                    alt=""
                                    loading="lazy"
                                    onerror="this.remove()"
                                >
                            <?php endif; ?>
                        </span>

                        <span class="tb-search-info">
                            <span
                                class="tb-search-badge tb-search-badge-<?php echo e($result->type); ?>"
                            >
                                <?php echo e($types[$result->type]); ?>

                            </span>

                            <?php if($hasArtist): ?>
                                <strong class="tb-search-artist">
                                    <?php echo e($result->artist_name); ?>

                                </strong>

                                <span class="tb-search-track">
                                    <?php echo e($resultTitle); ?>

                                </span>
                            <?php else: ?>
                                <strong class="tb-search-title">
                                    <?php echo e($result->title); ?>

                                </strong>
                            <?php endif; ?>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="tb-search-empty">
                        No results found. Try fewer words, another
                        spelling or select All Results.
                    </div>
                <?php endif; ?>
            </div>

            <?php echo $__env->make('partials.pagination', [
                'paginator' => $results,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($query !== ''): ?>
            <div class="tb-search-empty">
                Enter an artist name or title containing letters or numbers.
            </div>
        <?php else: ?>
            <div class="tb-search-empty">
                Search music, videos, DJ mixes, albums, blog posts,
                artists and DJs using the form above.
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/search.blade.php ENDPATH**/ ?>