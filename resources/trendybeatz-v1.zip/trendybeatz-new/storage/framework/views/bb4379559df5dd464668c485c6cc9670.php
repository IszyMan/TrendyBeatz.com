

<?php $__env->startSection('title', 'Edit DJ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Edit <?php echo e($dj->dj_name); ?></h1>
        <a href="<?php echo e(route('admin.djs.index')); ?>">← All DJs</a>
    </div>

    <?php echo $__env->make('admin.djs.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/djs/edit.blade.php ENDPATH**/ ?>