

<?php $__env->startSection('title', 'Edit DJ Mix'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Edit DJ Mix #<?php echo e($mix->id); ?></h1>
        <a href="<?php echo e(route('admin.dj-mixes.index')); ?>">← All DJ Mixes</a>
    </div>

    <?php echo $__env->make('admin.dj-mixes.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/dj-mixes/edit.blade.php ENDPATH**/ ?>