

<?php
    $artistName = trim((string) $album->artist_name);
    $albumTitle = trim((string) $album->title);
    $displayTitle = $artistName . ' - ' . $albumTitle;

    $pageTitle = 'DOWNLOAD: ' . $displayTitle
        . ' » TrendyBeatz';

    $descriptionStart = 'Download '
        . $artistName . ' ' . $albumTitle . ':';

    $albumWriteUp = trim(
        preg_replace(
            '/\s+/',
            ' ',
            strip_tags((string) $album->description)
        )
    );

    $pageDescription = $descriptionStart . ' '
        . ($albumWriteUp !== ''
            ? $albumWriteUp
            : 'Explore the tracklist, release details and songs on TrendyBeatz.');

    $pageDescription = \Illuminate\Support\Str::limit(
        $pageDescription,
        160,
        ''
    );

    $metaKeywords = implode(', ', [
        $artistName . ' ' . $albumTitle,
        'Download ' . $artistName . ' ' . $albumTitle,
        'Stream ' . $albumTitle,
        'Download ' . $artistName . ' ' . $albumTitle . ' album',
        'download album mp3 ' . $artistName . ' ' . $albumTitle,
        'Download ' . $displayTitle,
        $artistName . ' ' . $albumTitle . ' free mp3',
        $albumTitle . ' tracklist',
        $artistName . ' albums',
        'TrendyBeatz album downloads',
    ]);

    $canonicalUrl = route('albums.show', [
        $album->id,
        $correctSlug,
    ]);

    $cover = trim((string) $album->cover_url);

    if ($cover === '') {
        $coverUrl = '';
    } elseif (preg_match('~^https?://~i', $cover)) {
        $coverUrl = $cover;
    } else {
        $coverPath = ltrim($cover, '/');

        $coverUrl = asset(
            str_starts_with($coverPath, 'images/')
                ? $coverPath
                : 'images/' . $coverPath
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('meta_keywords', $metaKeywords); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $displayTitle . ' Album'); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($coverUrl !== ''): ?>
    <?php $__env->startSection('social_image', $coverUrl); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <?php
        $releaseDate = $album->released_date
            ? \Illuminate\Support\Carbon::parse($album->released_date)
            : null;

        $currentDate = now();
    ?>

    <article class="tb-music-detail tb-music-detail-primary tb-album-detail">
        <header class="tb-music-detail-header">
            <h1>
                <?php echo e($displayTitle); ?> 
            </h1>

            <div class="tb-music-detail-cover">
                <span
                    class="tb-music-detail-placeholder"
                    aria-hidden="true"
                >
                    TB
                </span>

                <?php if($coverUrl !== ''): ?>
                    <img
                        src="<?php echo e($coverUrl); ?>"
                        alt="<?php echo e($displayTitle); ?> album cover"
                        onerror="this.remove()"
                    >
                <?php endif; ?>
            </div>

            <p class="tb-music-detail-posted">
                <?php if($album->posted_by_name): ?>
                Posted By:

                <a
                    class="tb-music-detail-poster-link"
                    href="<?php echo e(route(
                        'albums.posted_by',
                        \Illuminate\Support\Str::slug($album->posted_by_name)
                    )); ?>"
                >
                    <strong><?php echo e($album->posted_by_name); ?></strong>
                </a>

                <span aria-hidden="true">•</span>
            <?php endif; ?>

                <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                    <?php echo e($currentDate->format('M d, Y')); ?>

                </time>
            </p>
        </header>

        <section class="tb-music-detail-section">
            

            <div class="tb-music-detail-facts">
                <p>
                    <strong>Album Artist:</strong>
                    <span class="tb-music-detail-blue">
                        <a
                            href="<?php echo e(route('artists.show', \Illuminate\Support\Str::slug($artistName))); ?>"
                            style="text-decoration: none;"
                        >
                            <?php echo e($artistName); ?>

                        </a>
                    </span>
                </p>

                <p>
                    <strong>Title:</strong>
                  <span class="tb-music-detail-green">  <?php echo e($albumTitle); ?></span>
                </p>

                <?php if($releaseDate): ?>
                    <p>
                        <strong>Released On:</strong>
                        <?php echo e($releaseDate->format('M d, Y')); ?>

                    </p>
                <?php endif; ?>

                <p>
                    <strong>Category:</strong>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('albums.index')); ?>"
                        style="text-decoration: none;"
                    >
                        Music Albums
                    </a>
                </p>                

                <?php if(filled($album->released_year)): ?>
                    <?php if(filled($album->released_year)): ?>
                        <p>
                            <strong>Released Year:</strong>
                            <a
                                class="tb-music-detail-red"
                                href="<?php echo e(route('albums.year', $album->released_year)); ?>"
                                style="text-decoration: none;"
                            >
                                <?php echo e($album->released_year); ?> Music Albums
                            </a>
                        </p>
                    <?php endif; ?>
                <?php endif; ?>


                <p>
                    <strong>Track List:</strong>
                    <?php echo e($tracks->count()); ?>

                </p>
            </div>
        </section>

        <section class="tb-music-detail-section">
            <h2 class="tb-music-detail-heading">
                About This Album
            </h2>

            <div class="tb-music-detail-description">
                <p class="tb-music-detail-introduction">
                    <?php echo e($descriptionStart); ?>

                </p>

                <?php if($albumWriteUp !== ''): ?>
                    <?php $__currentLoopData = preg_split('/\R{2,}/', trim((string) $album->description)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(filled(strip_tags($paragraph))): ?>
                            <p><?php echo e(strip_tags($paragraph)); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>
                        Explore <?php echo e($displayTitle); ?> and discover its
                        songs below.
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <section class="tb-music-detail-section" id="album-tracklist">
            <h2 class="tb-music-detail-heading">
                <?php echo e($displayTitle); ?> Tracklist
            </h2>

            <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a
                    class="tb-album-detail-track"
                    href="<?php echo e(\App\Support\MusicUrl::detail($song)); ?>"
                >
                    <span class="tb-album-detail-track-number">
                        <?php echo e($loop->iteration); ?>.
                    </span>

                    <span class="tb-album-detail-track-info">
                        <strong>
                            <?php echo e($song->track_title); ?>

                        </strong>

                        <?php if(filled($song->featuring)): ?>
                            <small>
                                <b>feat. <?php echo e($song->featuring); ?></b>
                            </small>
                        <?php endif; ?>

                        <small>Tap to Stream</small>
                    </span>

                    

                    <span
                        class="tb-album-detail-track-arrow"
                        aria-hidden="true"
                    >
                        →
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="tb-album-detail-empty">
                    No published songs are available for this album yet.
                </p>
            <?php endif; ?>
        </section>
    </article>


    

    <section class="tb-share-card">
        <p class="tb-share-heading">
            🔗 Share <?php echo e($displayTitle); ?> with others on
        </p>

        <div class="tb-share-row">
            <button
                type="button"
                class="tb-share-copy"
                onclick="tbCopyPageLink(this)"
                aria-live="polite"
            >Copy Link</button>
            <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
                <a class="a2a_button_facebook"></a>
                <a class="a2a_button_x"></a>
                <a class="a2a_button_email"></a>
                <a class="a2a_button_pinterest"></a>
                <a class="a2a_button_linkedin"></a>
                <a class="a2a_button_whatsapp"></a>
            </div>

            
        </div>
    </section>

    <div class="tb-music-detail tb-music-detail-related tb-album-detail">
        <?php if($otherAlbums->isNotEmpty()): ?>
            <section class="tb-music-detail-discovery">
                <h2 class="tb-music-detail-heading">
                    More Albums by <?php echo e($artistName); ?>

                </h2>

                <div class="tb-music-detail-discovery-list">
                    <?php $__currentLoopData = $otherAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherAlbum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $otherSlug = \Illuminate\Support\Str::slug(
                                $artistName . ' ' . $otherAlbum->title
                            );
                        ?>

                        <a
                            href="<?php echo e(route('albums.show', [
                                $otherAlbum->id,
                                $otherSlug,
                            ])); ?>"
                        >
                            <span
                                class="tb-music-detail-icon"
                                aria-hidden="true"
                            >
                                ♫
                            </span>

                            <span class="tb-music-detail-discovery-text">
                                <strong>
                                    <?php echo e($artistName); ?> -
                                    <?php echo e($otherAlbum->title); ?>

                                </strong>

                                <?php if(filled($otherAlbum->released_year)): ?>
                                    <small>
                                        Released in
                                        <?php echo e($otherAlbum->released_year); ?>

                                    </small>
                                <?php endif; ?>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        <p class="tb-home-view-all">
            <a href="<?php echo e(route('albums.index')); ?>">
                Browse All Albums →
            </a>
        </p>
    </div>


    <?php echo $__env->make('partials.comments', [
        'postType' => 'album',
        'postId' => $album->id,
        'postTitle' => $displayTitle,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/album-details.blade.php ENDPATH**/ ?>