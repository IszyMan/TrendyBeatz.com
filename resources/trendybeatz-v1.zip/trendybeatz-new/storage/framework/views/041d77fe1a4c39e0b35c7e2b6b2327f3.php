

<?php
    $artistSlug = \Illuminate\Support\Str::slug($artistName);

    $pageTitle = 'Download Latest ' . $artistName
        . ' Songs, Music, Albums, Biography, Profile, All Music, Videos'
        . ' - TrendyBeatz';

    $pageDescription = 'Explore ' . $artistName
        . '\'s biography, latest songs, music videos and albums'
        . ' on TrendyBeatz. Discover releases and browse the artist\'s'
        . ' music profile.';

    $canonicalUrl = route('artists.show', $artistSlug);

    $photo = trim((string) $artist->ProfilePic);

    if ($photo === '') {
        $photoUrl = '';
    } elseif (preg_match('~^https?://~i', $photo)) {
        $photoUrl = $photo;
    } else {
        $photoPath = ltrim($photo, '/');

        $photoUrl = asset(
            str_starts_with($photoPath, 'images/')
                ? $photoPath
                : 'images/' . $photoPath
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $artistName . ' Songs, Albums and Videos | TrendyBeatz'); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($photoUrl !== ''): ?>
    <?php $__env->startSection('social_image', $photoUrl); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <article class="tb-artist-detail">
        <header class="tb-artist-detail-heading">
            <h1 class="section-heading">
                Download Latest <?php echo e($artistName); ?> Songs, Albums,
                Biography, All Music, and Videos Here on TrendyBeatz
            </h1>

            <?php
                $currentDate = now();
            ?>

            <p class="tb-day-page-date">
                <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                    <?php echo e($currentDate->format('M d, Y')); ?>

                </time>
            </p>
        </header>

        <section
            class="tb-artist-detail-profile"
            aria-label="<?php echo e($artistName); ?> profile"
        >
            <div class="tb-artist-detail-photo">
                <span class="tb-artist-detail-placeholder" aria-hidden="true">
                    TB
                </span>

                <?php if($photoUrl !== ''): ?>
                    <img
                        src="<?php echo e($photoUrl); ?>"
                        alt="<?php echo e($artistName); ?> profile photo"
                        onerror="this.remove()"
                    >
                <?php endif; ?>
            </div>

            <div class="tb-artist-detail-facts">
                <?php if(filled($artist->Fullname)): ?>
                    <p>
                        <strong>Name:</strong>
                        <span><?php echo e($artist->Fullname); ?></span>
                    </p>
                <?php endif; ?>

                <p>
                    <strong>Also Known As:</strong>
                    <span><?php echo e($artistName); ?></span>
                </p>

                <?php if(filled($artist->RecordLabel)): ?>
                    <p>
                        <strong>Record Label:</strong>
                        <span><?php echo e($artist->RecordLabel); ?></span>
                    </p>
                <?php endif; ?>

                <?php if(filled($artist->Genres)): ?>
                    <p>
                        <strong>Genre:</strong>
                        <span><?php echo e($artist->Genres); ?></span>
                    </p>
                <?php endif; ?>

                <?php
                    $artistCountry = strtolower(trim((string) ($artist->country_id ?? '')));
                ?>

                <?php if(in_array($artistCountry, ['naija', 'ghana', 'african'], true)): ?>
                    <p>
                        <strong>Country:</strong>
                     <span>   <a
                            href="<?php echo e(route('music.' . $artistCountry)); ?>"
                            style="text-decoration: none;"
                        >
                            <?php echo e(ucfirst($artistCountry)); ?>

                        </a></span>
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <?php if(filled($artist->ArtistsProfile) || filled($artist->Place_Birth)): ?>
            <section class="tb-artist-detail-bio">
                <h2 class="sub-section-heading">
                    <?php echo e($artistName); ?> Biography
                </h2>

                <?php if(filled($artist->Place_Birth)): ?>
                    <p><?php echo e(strip_tags($artist->Place_Birth)); ?></p>
                <?php endif; ?>

            </section>
        <?php endif; ?>

        <h2 class="tb-artist-detail-intro">
            Download All <?php echo e($artistName); ?> Latest Songs, Albums
            and Videos Below
        </h2>

        
        <?php if($albums->isNotEmpty()): ?>
            <section class="tb-artist-detail-section" id="albums">
                <h2 class="sub-section-heading">
                    <?php echo e($artistName); ?> Albums and Tracklists
                </h2>

                <div class="tb-artist-album-list">
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cover = trim((string) $album->cover_url);

                            if ($cover === '') {
                                $coverUrl = null;
                            } elseif (preg_match('~^https?://~i', $cover)) {
                                $coverUrl = $cover;
                            } else {
                                $coverPath = ltrim($cover, '/');

                                $coverUrl = asset(
                                    str_starts_with($coverPath, 'images/')
                                        ? $coverPath
                                        : 'images/' . $coverPath
                                );
                            }

                            $albumSlug = \Illuminate\Support\Str::slug(
                                $artistName . ' ' . $album->title
                            );

                            $tracks = $albumTracks->get(
                                $album->id,
                                collect()
                            );
                        ?>

                        <details
                            class="tb-artist-album"
                            <?php if($loop->first): ?> open <?php endif; ?>
                        >
                            <summary class="tb-artist-album-summary">
                                <span class="tb-artist-album-cover">
                                    <span aria-hidden="true">Album</span>

                                    <?php if($coverUrl): ?>
                                        <img
                                            src="<?php echo e($coverUrl); ?>"
                                            alt="<?php echo e($artistName); ?> - <?php echo e($album->title); ?> album cover"
                                            loading="lazy"
                                            onerror="this.remove()"
                                        >
                                    <?php endif; ?>
                                </span>

                                <span class="tb-artist-album-info">
                                    <strong class="tb-artist-album-title">
                                        <?php echo e($artistName); ?> - <?php echo e($album->title); ?>

                                    </strong>

                                    <?php if(filled($album->released_year)): ?>
                                        <span class="tb-artist-album-meta">
                                            Released in <?php echo e($album->released_year); ?>

                                        </span>
                                    <?php endif; ?>

                                    <span class="tb-artist-album-meta">
                                        <?php echo e($tracks->count()); ?>

                                        <?php echo e(\Illuminate\Support\Str::plural(
                                            'track',
                                            $tracks->count()
                                        )); ?>

                                    </span>

                                    <span class="tb-artist-album-toggle">
                                        <span class="tb-artist-album-show">
                                            Show tracklist
                                        </span>
                                        <span class="tb-artist-album-hide">
                                            Hide tracklist
                                        </span>
                                        <span aria-hidden="true">⌄</span>
                                    </span>
                                </span>
                            </summary>

                            <div class="tb-artist-album-body">
                                <?php if($tracks->isNotEmpty()): ?>
                                    <ol class="tb-artist-album-tracks">
                                         <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(\App\Support\MusicUrl::detail($song)); ?>">
                                                    <span class="tb-artist-album-track-number">
                                                        <?php echo e($loop->iteration); ?>.
                                                    </span>

                                                    <span class="tb-artist-album-track-text">
                                                        <strong><?php echo e($song->track_title); ?></strong>

                                                        <?php if(filled($song->featuring)): ?>
                                                            <small>
                                                                <b>feat. <?php echo e($song->featuring); ?></b>
                                                            </small>
                                                        <?php endif; ?>

                                                        <small class="tb-artist-album-track-stream">
                                                            Tap to Stream
                                                        </small>
                                                    </span>

                                                    <span
                                                        class="tb-artist-album-track-arrow"
                                                        aria-hidden="true"
                                                    >
                                                        →
                                                    </span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php else: ?>
                                    <p class="tb-artist-album-empty">
                                        No published tracks are available for
                                        this album yet.
                                    </p>
                                <?php endif; ?>

                                <?php if(\Illuminate\Support\Facades\Route::has('albums.show')): ?>
                                    <a
                                        class="tb-artist-album-view"
                                        href="<?php echo e(route('albums.show', [
                                            $album->id,
                                            $albumSlug,
                                        ])); ?>"
                                    >
                                        View Album →
                                    </a>
                                <?php endif; ?>
                            </div>
                        </details>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        
        <?php if($singles->isNotEmpty()): ?>
            <section class="tb-artist-detail-section" id="singles">
                <h2 class="sub-section-heading">
                    <?php echo e($artistName); ?> Latest Single Songs
                </h2>

                <div class="tb-artist-detail-grid">
                    <?php $__currentLoopData = $singles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cover = trim((string) $song->cover_url);

                            if ($cover === '') {
                                $coverUrl = null;
                            } elseif (preg_match('~^https?://~i', $cover)) {
                                $coverUrl = $cover;
                            } else {
                                $coverPath = ltrim($cover, '/');

                                $coverUrl = asset(
                                    str_starts_with($coverPath, 'images/')
                                        ? $coverPath
                                        : 'images/' . $coverPath
                                );
                            }
                        ?>

                        <a
                            class="tb-artist-detail-card"
                            href="<?php echo e(\App\Support\MusicUrl::detail($song)); ?>"
                        >
                            <span class="tb-artist-detail-card-image">
                                <span aria-hidden="true">TB</span>

                                <?php if($coverUrl): ?>
                                    <img
                                        src="<?php echo e($coverUrl); ?>"
                                        alt="<?php echo e($artistName); ?> - <?php echo e($song->track_title); ?> cover"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                <?php endif; ?>
                            </span>

                            <span class="tb-artist-detail-card-content">
                                <strong class="tb-artist-detail-card-title">
                                    <?php echo e($artistName); ?> -
                                    <?php echo e($song->track_title); ?>

                                </strong>

                                <?php if(filled($song->featuring)): ?>
                                    <span class="tb-artist-detail-card-featuring">
                                        feat. <?php echo e($song->featuring); ?>

                                    </span>
                                <?php endif; ?>

                                <span class="tb-artist-detail-card-action">
                                    Discover &amp; Stream →
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        
        <?php if($videos->isNotEmpty()): ?>
            <section class="tb-artist-detail-section" id="videos">
                <h2 class="sub-section-heading">
                    <?php echo e($artistName); ?> Videos
                </h2>

                <div class="tb-artist-detail-grid">
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cover = trim((string) $video->cover_url);

                            if ($cover === '') {
                                $coverUrl = null;
                            } elseif (preg_match('~^https?://~i', $cover)) {
                                $coverUrl = $cover;
                            } else {
                                $coverPath = ltrim($cover, '/');

                                $coverUrl = asset(
                                    str_starts_with($coverPath, 'images/')
                                        ? $coverPath
                                        : 'images/' . $coverPath
                                );
                            }
                        ?>

                        <a
                            class="tb-artist-detail-card"
                            href="<?php echo e(\App\Support\VideoUrl::detail($video)); ?>"
                        >
                            <span class="tb-artist-detail-card-image">
                                <span aria-hidden="true">TB</span>
                                <span
                                    class="tb-artist-detail-play"
                                    aria-hidden="true"
                                >
                                    ▶
                                </span>

                                <?php if($coverUrl): ?>
                                    <img
                                        src="<?php echo e($coverUrl); ?>"
                                        alt="<?php echo e($artistName); ?> - <?php echo e($video->track_title); ?> video cover"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                <?php endif; ?>
                            </span>

                            <span class="tb-artist-detail-card-content">
                                <strong class="tb-artist-detail-card-title">
                                    <?php echo e($artistName); ?> -
                                    <?php echo e($video->track_title); ?>

                                </strong>

                                <?php if(filled($video->featuring)): ?>
                                    <span class="tb-artist-detail-card-featuring">
                                        feat. <?php echo e($video->featuring); ?>

                                    </span>
                                <?php endif; ?>

                                <span class="tb-artist-detail-card-action">
                                    Watch Video →
                                </span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

        

    <section class="tb-share-card">
        <p class="tb-share-heading">
            🔗 Share <?php echo e($artistName); ?> Profile with others on
        </p>

        <div class="tb-share-row">
            <button
                type="button"
                class="tb-share-copy"
                onclick="tbCopyPageLink(this)"
                aria-live="polite"
            >Copy Link</button>
            <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
                <a class="a2a_button_facebook"></a>
                <a class="a2a_button_x"></a>
                <a class="a2a_button_email"></a>
                <a class="a2a_button_pinterest"></a>
                <a class="a2a_button_linkedin"></a>
                <a class="a2a_button_whatsapp"></a>
            </div>

            
        </div>
    </section>

        <p class="tb-home-view-all">
            <a href="<?php echo e(route('artists.index')); ?>">
                ← Browse All Artists
            </a>
        </p>

        
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/artist-details.blade.php ENDPATH**/ ?>