

<?php
    $isCategoryPage = $selectedCategory !== null;

    $heading = $isCategoryPage
        ? $selectedCategory->name
        : 'Latest Blog & News';

    $pageTitle = $isCategoryPage
        ? $heading . ' - Latest Stories | TrendyBeatz'
        : 'Music News - Top Naija Celebrity News, Entertainment Gists & Updates | TrendyBeatz';

    $pageDescription = $isCategoryPage
        ? 'Explore the latest ' . $selectedCategory->name
            . ' stories, updates and articles on TrendyBeatz.'
        : 'Read the latest Nigerian music news, celebrity stories, entertainment updates, music reviews and trending conversations on TrendyBeatz.';

    $baseUrl = $isCategoryPage
        ? route('blogs.category', $selectedCategory->slug)
        : route('blogs.index');

    $canonicalUrl = $posts->currentPage() === 1
        ? $baseUrl
        : $posts->url($posts->currentPage());

    $firstPhoto = trim((string) ($posts->first()->photo ?? ''));

    if ($firstPhoto === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $firstPhoto)) {
        $socialImage = $firstPhoto;
    } else {
        $firstPhotoPath = ltrim($firstPhoto, '/');

        $socialImage = asset(
            str_starts_with($firstPhotoPath, 'images/')
                ? $firstPhotoPath
                : 'images/blog/' . basename($firstPhotoPath)
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php if($posts->currentPage() > 1): ?>
    <?php $__env->startSection(
        'previous_url',
        $posts->currentPage() === 2
            ? $baseUrl
            : $posts->previousPageUrl()
    ); ?>
<?php endif; ?>

<?php if($posts->hasMorePages()): ?>
    <?php $__env->startSection('next_url', $posts->nextPageUrl()); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <section class="tb-news-page">
        <h1 class="section-heading">
            <?php echo e($heading); ?>

        </h1>

        <?php
            $currentDate = now();

            $categoryClasses = [
                'sport-news' => 'tb-blog-sport',
                'celebrity-news' => 'tb-blog-celebrity',
                'hot-gists' => 'tb-blog-gists',
                'networth' => 'tb-blog-networth',
                'music-reviews' => 'tb-blog-reviews',
                'education' => 'tb-blog-education',
                'articles' => 'tb-blog-articles',
                'news' => 'tb-blog-news',
            ];
        ?>

        <p class="home-date">
            <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                <?php echo e($currentDate->format('M d, Y')); ?>

            </time>
        </p>

        <nav class="tb-blog-categories" aria-label="Blog categories">
            <a
                href="<?php echo e(route('blogs.index')); ?>"
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'tb-blog-category-button',
                    'tb-blog-all',
                    'active' => !$isCategoryPage,
                ]); ?>"
                <?php if(!$isCategoryPage): ?> aria-current="page" <?php endif; ?>
            >
                All Posts
            </a>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    href="<?php echo e(route('blogs.category', $category->slug)); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'tb-blog-category-button',
                        $categoryClasses[$category->slug] ?? 'tb-blog-news',
                        'active' => $isCategoryPage
                            && $selectedCategory->id === $category->id,
                    ]); ?>"
                    <?php if(
                        $isCategoryPage
                        && $selectedCategory->id === $category->id
                    ): ?>
                        aria-current="page"
                    <?php endif; ?>
                >
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <h2 class="sub-section-heading">
            <?php echo e($isCategoryPage ? $heading . ' Posts' : 'All Blog Posts'); ?>

        </h2>

        <div class="tb-news-page-list">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('partials.blogs.card', [
                    'post' => $post,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="tb-home-empty">
                    No published posts in this section yet.
                </p>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.pagination', [
            'paginator' => $posts,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/blogs.blade.php ENDPATH**/ ?>