<?php
    $editing = $album !== null;

    $selectedArtist = (string) old(
        'artist_id',
        $album->artist_id ?? ''
    );
?>

<form
    class="admin-panel admin-form-grid"
    method="POST"
    enctype="multipart/form-data"
    action="<?php echo e($editing
        ? route('admin.albums.update', $album->id)
        : route('admin.albums.store')); ?>"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>

        <p class="admin-field-wide">
            <strong>Album ID:</strong> <?php echo e($album->id); ?>

        </p>
    <?php endif; ?>

    <?php if(!$editing): ?>
        <label class="admin-field">
            Album ID (optional)

            <input
                type="number"
                name="album_id"
                min="1"
                step="1"
                value="<?php echo e(old('album_id')); ?>"
                placeholder="Leave blank for automatic ID"
            >

            <small>
                Enter an unused ID, or leave blank to assign one automatically.
            </small>

            <?php $__errorArgs = ['album_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: #b91c1c;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
    <?php endif; ?>

   <!-- <label class="admin-field admin-field-wide">
        Search artists

        <input
            type="search"
            id="album-artist-search"
            placeholder="Search by artist name..."
            autocomplete="off"
        >
    </label>-->

    <label class="admin-field admin-field-wide">
        Artist

        <select name="artist_id" id="album-artist" required>
            <option value="">Choose an existing artist</option>

            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($artist->id); ?>"
                    <?php if($selectedArtist === (string) $artist->id): echo 'selected'; endif; ?>
                >
                    <?php echo e($artist->stage_name ?: $artist->full_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php if($artists->isEmpty()): ?>
            <small>
                Create an artist profile before adding an album.
            </small>
        <?php endif; ?>
    </label>

    <label class="admin-field admin-field-wide">
        Album title

        <input
            type="text"
            name="title"
            maxlength="191"
            value="<?php echo e(old('title', $album->title ?? '')); ?>"
            required
        >
    </label>

    <label class="admin-field">
        Featuring

        <input
            type="text"
            name="featuring"
            maxlength="191"
            value="<?php echo e(old('featuring', $album->featuring ?? '')); ?>"
        >
    </label>

    <label class="admin-field">
        Release year

        <input
            type="number"
            name="released_year"
            min="1900"
            max="2099"
            step="1"
            value="<?php echo e(old('released_year', $album->released_year ?? '')); ?>"
            required
        >
    </label>

    <label class="admin-field">
        Release date

        <input
            type="date"
            name="released_date"
            value="<?php echo e(old('released_date', $album->released_date ?? '')); ?>"
        >
    </label>

    <label class="admin-field admin-field-wide">
        Description

        <textarea
            name="description"
            rows="8"
        ><?php echo e(old('description', $album->description ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Album cover

        <input
            type="file"
            name="cover_image"
            accept="image/jpeg,image/png,image/webp,image/gif"
        >

        <?php if($editing && filled($album->cover_url)): ?>
            <small>
                Current image: <?php echo e($album->cover_url); ?>

            </small>
        <?php endif; ?>
    </label>

    <input type="hidden" name="IsPublished" value="NO">

    <div class="admin-checks admin-field-wide">
        <label>
            <input
                type="checkbox"
                name="IsPublished"
                value="YES"
                <?php if(
                    old('IsPublished', $album->IsPublished ?? 'NO') === 'YES'
                ): echo 'checked'; endif; ?>
            >

            Published
        </label>
    </div>

    <div class="admin-field-wide">
        <button
            class="admin-button"
            type="submit"
            <?php if($artists->isEmpty()): echo 'disabled'; endif; ?>
        >
            <?php echo e($editing ? 'Save Changes' : 'Create Album'); ?>

        </button>
    </div>
</form>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const search = document.getElementById('album-artist-search');
        const select = document.getElementById('album-artist');

        if (!search || !select) {
            return;
        }

        const allOptions = Array.from(select.options).map(option => ({
            value: option.value,
            text: option.textContent.trim()
        }));

        search.addEventListener('input', () => {
            const query = search.value.trim().toLowerCase();
            const selectedValue = select.value;

            select.replaceChildren();

            for (const item of allOptions) {
                if (
                    item.value === ''
                    || item.value === selectedValue
                    || item.text.toLowerCase().includes(query)
                ) {
                    select.add(new Option(
                        item.text,
                        item.value,
                        false,
                        item.value === selectedValue
                    ));
                }
            }

            select.value = selectedValue;
        });
    });
</script><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/albums/form.blade.php ENDPATH**/ ?>