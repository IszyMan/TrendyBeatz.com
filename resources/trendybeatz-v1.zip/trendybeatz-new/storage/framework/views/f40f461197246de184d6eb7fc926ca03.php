<footer class="site-footer">
    <div class="footer-columns">
        <section>
            <h2>Quick Link</h2>

            <a href="<?php echo e(route('home')); ?>#song-of-the-week">
                Top Ten Music
            </a>

            <a href="<?php echo e(route('videos.index')); ?>">
                Latest Videos
            </a>

            <a href="<?php echo e(route('music.naija')); ?>">
                Download Musics
            </a>

            <a href="<?php echo e(route('blogs.category', 'celebrity-news')); ?>">
                Celebrity News
            </a>

            <a href="<?php echo e(route('page.promote')); ?>">
                Upload Your Songs
            </a>

            <a href="<?php echo e(route('page.promote')); ?>">
                Music Promotion
            </a>
        </section>

        <section>
            <h2>Hall of Fame</h2>

            <a href="<?php echo e(route('artists.index')); ?>">
                Artiste Profile
            </a>

            <a href="<?php echo e(route('albums.index')); ?>">
                Artiste Album
            </a>

            <a href="<?php echo e(route('blogs.category', 'hot-gists')); ?>">
                Hot Gist
            </a>

            <a href="<?php echo e(route('mixes.index')); ?>">
                DJ Mix
            </a>

            <a href="<?php echo e(route('djs.index')); ?>">
                DJs Profile
            </a>
        </section>

        <section>
            <h2>Company</h2>

            <a href="<?php echo e(route('page.about')); ?>">
                About Us
            </a>

            <a href="<?php echo e(route('page.terms')); ?>">
                Terms of Use
            </a>

            <a href="<?php echo e(route('page.privacy')); ?>">
                Privacy Policy
            </a>

            <a href="<?php echo e(route('page.contact')); ?>">
                Contact Us
            </a>

            <a href="<?php echo e(route('page.advertise')); ?>">
                Advertise With Us
            </a>

            <a href="<?php echo e(route('page.dmca')); ?>">
                DMCA
            </a>

            <a href="<?php echo e(route('page.disclaimer')); ?>">
                Disclaimer
            </a>
        </section>

        <section class="footer-address">
            <h2>Address</h2>

            <p>Lekki Peninsula<br>Lekki, Lagos, Nigeria</p>

            <p>For advert and business enquiries:</p>

            <a href="mailto:info@trendybeatz.com">
                info@trendybeatz.com
            </a>

            <a href="https://wa.me/2349076131844">
                Contact Us on WhatsApp
            </a>

            <button
                type="button"
                class="back-to-top"
                onclick="window.scrollTo({ top: 0, behavior: 'smooth' })"
            >
                Back to Top ↑
            </button>
        </section>
    </div>

    <div class="footer-copyright">
        Copyright <?php echo e(date('Y')); ?> © TrendyBeatz Media
    </div>
</footer><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/layouts/footer.blade.php ENDPATH**/ ?>