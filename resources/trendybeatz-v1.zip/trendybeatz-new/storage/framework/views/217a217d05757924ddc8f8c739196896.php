

<?php
    /*
     * Page metadata. Visible page values are prepared inside
     * the content section below.
     */
    $metaDjName = trim((string) ($mix->dj_name ?: 'TrendyBeatz DJ'));
    $metaMixTitle = trim((string) $mix->mix_title);

    $pageTitle = 'Download Mix: '
        . $metaDjName
        . ' - '
        . $metaMixTitle
        . ' Mix';

    $descriptionText = trim(strip_tags(
        (string) ($mix->details ?: $mix->description1 ?: '')
    ));

    $pageDescription = 'Download '
        . $metaDjName
        . ' '
        . $metaMixTitle
        . ' Mix.';

    if ($descriptionText !== '') {
        $pageDescription .= ' ' . $descriptionText;
    }

    $pageDescription = \Illuminate\Support\Str::limit(
        preg_replace('/\s+/', ' ', $pageDescription),
        260,
        ''
    );

    $metaKeywords = implode(', ', [
        $metaDjName . ' ' . $metaMixTitle,
        'Download ' . $metaDjName . ' ' . $metaMixTitle,
        'Stream ' . $metaMixTitle,
        'Download ' . $metaDjName . ' ' . $metaMixTitle . ' mix',
        'download mp3 ' . $metaDjName . ' ' . $metaMixTitle,
        'Download ' . $metaDjName . ' - ' . $metaMixTitle,
        $metaDjName . ' ' . $metaMixTitle . ' free mp3',
        $metaDjName . ' mixtapes',
        'TrendyBeatz DJ mixes',
    ]);

    $canonicalUrl = route('mixes.show', [
        $mix->id,
        $canonicalSlug,
    ]);

    $metaCover = trim((string) $mix->cover_url);

    if ($metaCover === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $metaCover)) {
        $socialImage = $metaCover;
    } else {
        $metaCoverPath = ltrim($metaCover, '/');

        $socialImage = asset(
            str_starts_with($metaCoverPath, 'images/')
                ? $metaCoverPath
                : 'images/' . basename($metaCoverPath)
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('meta_keywords', $metaKeywords); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $metaDjName . ' - ' . $metaMixTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <?php
        $djName = trim((string) ($mix->dj_name ?: 'TrendyBeatz DJ'));
        $mixTitle = trim((string) $mix->mix_title);
        $displayTitle = $djName . ' - ' . $mixTitle;

        $cover = trim((string) $mix->cover_url);

        if ($cover === '') {
            $coverUrl = null;
        } elseif (preg_match('~^https?://~i', $cover)) {
            $coverUrl = $cover;
        } else {
            $coverPath = ltrim($cover, '/');

            $coverUrl = asset(
                str_starts_with($coverPath, 'images/')
                    ? $coverPath
                    : 'images/' . basename($coverPath)
            );
        }

        $track = trim((string) $mix->track_url);

        if ($track === '') {
            $trackUrl = null;
        } elseif (preg_match('~^https?://~i', $track)) {
            $trackUrl = $track;
        } else {
            $trackUrl = asset(ltrim($track, '/'));
        }

        $currentDate = now();
    ?>

    
    <article class="tb-music-detail tb-music-detail-primary tb-mix-detail">
        <header class="tb-music-detail-header">
            <h1>
                <?php echo e($displayTitle); ?> | Download Mix MP3
            </h1>

            <div class="tb-music-detail-cover tb-mix-detail-cover">
                <span class="tb-music-detail-placeholder" aria-hidden="true">
                    TB
                </span>

                <?php if($coverUrl): ?>
                    <img
                        src="<?php echo e($coverUrl); ?>"
                        alt="<?php echo e($displayTitle); ?> mixtape cover"
                        onerror="this.remove()"
                    >
                <?php endif; ?>
            </div>

            <p class="tb-music-detail-posted">
                <?php if($mix->posted_by_name): ?>
                    Posted By:
                    <a
                        class="tb-music-detail-poster-link"
                        href="<?php echo e(route('mixes.posted_by', \Illuminate\Support\Str::slug($mix->posted_by_name))); ?>"
                    >
                        <strong><?php echo e($mix->posted_by_name); ?></strong>
                    </a>

                    <span aria-hidden="true">•</span>
                <?php endif; ?>

               
                <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                    <?php echo e($currentDate->format('M d, Y')); ?>

                </time>
            </p>
        </header>

        <section class="tb-music-detail-section">
            

            <div class="tb-music-detail-facts">
                <p>
                    <strong>DJ:</strong>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('djs.show', \Illuminate\Support\Str::slug($mix->dj_name))); ?>"
                        style="text-decoration: none;"
                    >
                         <span class="tb-music-detail-blue"><?php echo e($djName); ?></span>
                    </a>
                </p>

                <p>
                    <strong>Mixtape:</strong>
                    <span class="tb-music-detail-red"><?php echo e($mixTitle); ?></span>
                </p>

                <?php if(filled($mix->released_year)): ?>
                    <p>
                        <strong>Year:</strong>
                        <a
                            class="tb-music-detail-green"
                            href="<?php echo e(route('mixes.year', $mix->released_year)); ?>"
                            style="text-decoration: none;"
                        >
                            <?php echo e($mix->released_year); ?>

                        </a>
                    </p>
                <?php endif; ?>

                <p>
                    <strong>Category:</strong>
                    <a
                        class="tb-music-detail-blue"
                        href="<?php echo e(route('mixes.index')); ?>"
                        style="text-decoration: none;"
                    >
                        Latest DJ Mix
                    </a>
                </p>
            </div>
        </section>

        <?php if(
            filled($mix->details)
            || filled($mix->details2)
            || filled($mix->description1)
            || filled($mix->description2)
        ): ?>
            <section class="tb-music-detail-section">
                <h2 class="tb-music-detail-heading">
                    About This DJ Mix
                </h2>

                <div class="tb-djmix-details-description">
                    <div class="tb-djmix-details-description">
                        <?php $__currentLoopData = [
                            $mix->details,
                            $mix->details2,
                            $mix->description1,
                            $mix->description2,
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(filled($paragraph)): ?>
                                <?php
                                    $text = preg_replace(
                                        '~<br\s*/?>|</p\s*>~i',
                                        "\n",
                                        (string) $paragraph
                                    );

                                    $text = trim(strip_tags($text));

                                    $paragraphs = preg_split(
                                        '/\R+/',
                                        $text,
                                        -1,
                                        PREG_SPLIT_NO_EMPTY
                                    );
                                ?>

                                <?php $__currentLoopData = $paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(trim($part) !== ''): ?>
                                        <p><?php echo e(trim($part)); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </section>
        <?php endif; ?>

        <?php
            $backCover = trim((string) ($mix->back_cover ?? ''));
            $backCoverUrl = null;

            if ($backCover !== '') {
                if (preg_match('~^https?://~i', $backCover)) {
                    $backCoverUrl = $backCover;
                } else {
                    $backCoverPath = ltrim($backCover, '/');

                    $backCoverUrl = asset(
                        str_starts_with($backCoverPath, 'images/')
                            ? $backCoverPath
                            : 'images/' . basename($backCoverPath)
                    );
                }
            }
        ?>

        <?php if($backCoverUrl): ?>
            <div class="tb-music-detail-cover tb-mix-detail-cover">
                <img
                    src="<?php echo e($backCoverUrl); ?>"
                    alt="<?php echo e($displayTitle); ?> mixtape back cover"
                    loading="lazy"
                    onerror="this.remove()"
                >
            </div>
        <?php endif; ?>

        <?php if($hasAudioFile): ?>
            <section class="tb-music-detail-listening">
                <h2>Listen to <?php echo e($displayTitle); ?></h2>

                <div class="tb-music-detail-audio">
                    <p class="tb-music-copyright-notice">
                        <strong>Copyright Notice:</strong>
                        This song and its audio materials were published upon
                        express request and direct permission from the
                        copyright holder.
                    </p>

                    <audio controls preload="none">
                        <source src="<?php echo e($trackUrl); ?>">
                        Your browser does not support audio playback.
                    </audio>
                </div>

                <a
                    class="tb-music-detail-download"
                    href="<?php echo e($trackUrl); ?>"
                    download
                >
                    Download <?php echo e($displayTitle); ?> Mix
                </a>
            </section>
        <?php endif; ?>
    </article>


    

    <section class="tb-share-card">
        <p class="tb-share-heading">
            🔗 Share <?php echo e($displayTitle); ?> Music with others on
        </p>

        <div class="tb-share-row">
            <button
                type="button"
                class="tb-share-copy"
                onclick="tbCopyPageLink(this)"
                aria-live="polite"
            >Copy Link</button>
            <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
                <a class="a2a_button_facebook"></a>
                <a class="a2a_button_x"></a>
                <a class="a2a_button_email"></a>
                <a class="a2a_button_pinterest"></a>
                <a class="a2a_button_linkedin"></a>
                <a class="a2a_button_whatsapp"></a>
            </div>

            
        </div>
    </section>

    
    <section class="tb-music-detail tb-music-detail-related tb-mix-detail-related">
        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                Download Latest &amp; Other Mixes By <?php echo e($djName); ?>

            </h2>

            <div class="tb-mix-detail-list">
                <?php $__empty_1 = true; $__currentLoopData = $otherMixesByDj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherMix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $otherSlug = trim(
                            (string) $otherMix->slug,
                            " \t\n\r\0\x0B/"
                        );

                        if ($otherSlug === '') {
                            $otherSlug = \Illuminate\Support\Str::slug(
                                $otherMix->dj_name . ' ' . $otherMix->mix_title
                            );
                        }

                        $otherCover = trim((string) $otherMix->cover_url);

                        if ($otherCover === '') {
                            $otherCoverUrl = null;
                        } elseif (preg_match('~^https?://~i', $otherCover)) {
                            $otherCoverUrl = $otherCover;
                        } else {
                            $otherPath = ltrim($otherCover, '/');

                            $otherCoverUrl = asset(
                                str_starts_with($otherPath, 'images/')
                                    ? $otherPath
                                    : 'images/' . basename($otherPath)
                            );
                        }
                    ?>

                    <a href="<?php echo e(\App\Support\DjMixUrl::detail($otherMix)); ?>">
                        <span class="tb-mix-detail-thumb">
                            <span aria-hidden="true">TB</span>

                            <?php if($otherCoverUrl): ?>
                                <img
                                    src="<?php echo e($otherCoverUrl); ?>"
                                    alt="<?php echo e($otherMix->dj_name); ?> - <?php echo e($otherMix->mix_title); ?> cover"
                                    loading="lazy"
                                    onerror="this.remove()"
                                >
                            <?php endif; ?>
                        </span>

                        <span class="tb-mix-detail-item-text">
                            <strong><?php echo e($otherMix->dj_name); ?></strong>
                            <span><b><?php echo e($otherMix->mix_title); ?></b></span>

                            <small>Listen & Download</small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="tb-home-empty">
                        No other mixes by <?php echo e($djName); ?> yet.
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <section class="tb-music-detail-discovery">
            <h2 class="tb-music-detail-heading">
                Discover Mixes From Other DJs
            </h2>

            <div class="tb-mix-detail-list">
                <?php $__empty_1 = true; $__currentLoopData = $otherDjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherDj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        
                        $djImage = trim((string) (
                            $otherDj->dj_photo ?: $otherDj->cover_url
                        ));

                        if ($djImage === '') {
                            $djImageUrl = null;
                        } elseif (preg_match('~^https?://~i', $djImage)) {
                            $djImageUrl = $djImage;
                        } else {
                            $djImagePath = ltrim($djImage, '/');

                            $djImageUrl = asset(
                                str_starts_with($djImagePath, 'images/')
                                    ? $djImagePath
                                    : 'images/' . basename($djImagePath)
                            );
                        }
                    ?>

                    <a href="<?php echo e(\App\Support\DjMixUrl::detail($otherDj)); ?>">
                        <span class="tb-mix-detail-thumb">
                            <span aria-hidden="true">DJ</span>

                            <?php if($djImageUrl): ?>
                                <img
                                    src="<?php echo e($djImageUrl); ?>"
                                    alt="<?php echo e($otherDj->dj_name); ?> photo"
                                    loading="lazy"
                                    onerror="this.remove()"
                                >
                            <?php endif; ?>
                        </span>

                        <span class="tb-mix-detail-item-text">
                            <strong><?php echo e($otherDj->dj_name); ?></strong>
                            <span><b><?php echo e($otherDj->mix_title); ?></b></span>
                            <small>Listen & Download</small>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="tb-home-empty">
                        No other DJs available yet.
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <p class="tb-home-view-all">
            <a href="<?php echo e(route('mixes.index')); ?>">
                View All Latest DJ Mix →
            </a>
        </p>
    </section>

    <?php echo $__env->make('partials.comments', [
        'postType' => 'djmix',
        'postId' => $mix->id,
        'postTitle' => $djName . ' - ' . $mix->mix_title,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/djmix-details.blade.php ENDPATH**/ ?>