

<?php
    $djName = trim((string) $dj->dj_name);

    $pageNumber = $mixes->currentPage();

    $pageTitle = 'Download Latest ' . $djName
        . ' Mix, DJ Mixtape, and Read Biography';

    if ($pageNumber > 1) {
        $pageTitle .= ' - Page ' . $pageNumber;
    }

    $description = 'Explore ' . $djName
        . ' mixtapes on TrendyBeatz. Browse recent DJ mixes, '
        . 'discover releases and open each mixtape for listening '
        . 'and available downloads.';

    $keywords = $djName . ' mixes, '
        . $djName . ' mixtapes, '
        . 'download ' . $djName . ' DJ mix, '
        . $djName . ' biography';

    $canonical = $pageNumber === 1
        ? route('djs.show', $slug)
        : route('djs.show', [
            'slug' => $slug,
            'page' => $pageNumber,
        ]);

    $imageUrl = static function ($value) {
        $path = trim((string) $value);

        if ($path === '') {
            return null;
        }

        if (preg_match('~^https?://~i', $path)) {
            return $path;
        }

        $path = ltrim($path, '/');

        return asset(
            str_starts_with($path, 'images/')
                ? $path
                : 'images/' . $path
        );
    };

    $photoUrl = $imageUrl($dj->photo ?? '');

    $biography = trim(strip_tags((string) ($dj->place_of_birth ?? '')));

    $awards = trim(strip_tags((string) ($dj->awards ?? '')));
    $endorsements = trim(strip_tags((string) ($dj->endorsements ?? '')));
?>

<?php $__env->startSection('title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('meta_keywords', $keywords); ?>
<?php $__env->startSection('meta_description', $description); ?>
<?php $__env->startSection('canonical', $canonical); ?>
<?php $__env->startSection('social_title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('social_description', $description); ?>

<?php if($photoUrl): ?>
    <?php $__env->startSection('social_image', $photoUrl); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <article class="tb-dj-detail">
        <header class="tb-dj-detail-heading">
            <h1 class="section-heading">
                <?php echo e($djName); ?> Mixtapes and DJ Profile
            </h1>
        </header>

        <section class="tb-dj-detail-profile" aria-label="DJ profile">
            <div class="tb-dj-detail-photo">
                <span class="tb-dj-detail-placeholder" aria-hidden="true">
                    DJ
                </span>

                <?php if($photoUrl): ?>
                    <img
                        src="<?php echo e($photoUrl); ?>"
                        alt="<?php echo e($djName); ?> profile"
                        onerror="this.remove()"
                    >
                <?php endif; ?>
            </div>

            <div class="tb-dj-detail-facts">
                <p>
                    <strong>Names:</strong>
                    <span><?php echo e($dj->fullname); ?></span>
                </p>

                <p>
                    <strong>Also Known As:</strong>
                    <span><?php echo e($djName); ?></span>
                </p>

                
            </div>
        </section>

        <?php if($biography !== ''): ?>
            <section class="tb-dj-detail-bio">
                <h2 class="sub-section-heading">
                    About <?php echo e($djName); ?>

                </h2>

                <?php $__currentLoopData = preg_split('/\R\s*\R/', $biography); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(trim($paragraph) !== ''): ?>
                        <p><?php echo e($paragraph); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <section class="tb-dj-detail-section">
            <h2 class="tb-dj-detail-intro">
                Discover <?php echo e($djName); ?> Mixtapes
            </h2>

            <div class="tb-dj-mixtape-list">
                <?php $__empty_1 = true; $__currentLoopData = $mixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mixtape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $coverUrl = $imageUrl($mixtape->cover_url);

                        $mixtape->dj_name = $djName;

                        
                    ?>

                    <a
                        class="tb-dj-mixtape"
                        href="<?php echo e(\App\Support\DjMixUrl::detail($mixtape)); ?>"
                    >
                        <span class="tb-dj-mixtape-cover">
                            <span aria-hidden="true">DJ Mix</span>

                            <?php if($coverUrl): ?>
                                <img
                                    src="<?php echo e($coverUrl); ?>"
                                    alt="<?php echo e($djName); ?> - <?php echo e($mixtape->mix_title); ?> cover"
                                    loading="lazy"
                                    onerror="this.remove()"
                                >
                            <?php endif; ?>
                        </span>

                        <span class="tb-dj-mixtape-info">
                            <span class="tb-dj-mixtape-name">
                                <?php echo e($djName); ?>

                            </span>

                            <strong class="tb-dj-mixtape-title">
                                <?php echo e($mixtape->mix_title); ?>

                            </strong>

                            <span class="tb-dj-mixtape-action">
                                Listen / Download →
                            </span>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="tb-dj-detail-empty">
                        No published mixtapes available yet.
                    </p>
                <?php endif; ?>
            </div>

            

        <p class="tb-home-view-all">
            <a href="<?php echo e(route('djs.index')); ?>">
                ← Browse All DJs
            </a>
        </p>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/djs-details.blade.php ENDPATH**/ ?>