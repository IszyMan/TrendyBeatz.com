

<?php $__env->startSection('title', 'Add Blog Post'); ?>

<?php $__env->startPush('styles'); ?>
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css"
    >
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="blog-page">
        <div class="admin-page-head">
            <h1>Add Blog Post</h1>
            <a href="<?php echo e(route('admin.blogs.index')); ?>">← All Blogs</a>
        </div>

        <?php echo $__env->make('admin.blogs.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('admin.blogs.editor-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>