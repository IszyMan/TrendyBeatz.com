

<?php $__env->startSection('title', 'All Albums'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All Albums</h1>

        <a class="admin-button" href="<?php echo e(route('admin.albums.create')); ?>">
            + Add Album
        </a>
    </div>

    <div class="admin-panel">
        <form
            class="admin-filters admin-album-filters"
            method="GET"
            action="<?php echo e(route('admin.albums.index')); ?>"
        >
            <label class="admin-field">
                Search
                <input
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    placeholder="Album title, ID or artist"
                >
            </label>

            <button class="admin-button" type="submit">Search</button>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Album / Artist</th>
                        <th>Year</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($album->id); ?></td>

                            <td>
                                <strong><?php echo e($album->title); ?></strong>
                                <br>
                                <?php echo e($album->Stage_Name ?: ($album->ArtistsName ?: '—')); ?>

                            </td>

                            <td><?php echo e($album->released_year); ?></td>
                            <td><?php echo e($album->IsPublished); ?></td>

                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route('admin.albums.edit', $album->id)); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route('admin.albums.destroy', $album->id)); ?>"
                                            onsubmit="return confirm('Delete this album?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-button admin-button-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No albums found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', ['paginator' => $albums], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/albums/index.blade.php ENDPATH**/ ?>