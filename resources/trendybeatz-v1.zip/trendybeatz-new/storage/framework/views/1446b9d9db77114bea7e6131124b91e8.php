

<?php $__env->startSection('title', 'All Blogs'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-blog.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All Blogs</h1>

        <a class="admin-button" href="<?php echo e(route('admin.blogs.create')); ?>">
            + Add Blog Post
        </a>
    </div>

    <div class="admin-panel">
        <form
            class="admin-filters blog-index-filters"
            method="GET"
            action="<?php echo e(route('admin.blogs.index')); ?>"
        >
            <label class="admin-field">
                Search
                <input
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    placeholder="Post title or category"
                >
            </label>

            <button class="admin-button" type="submit">Search</button>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Post</th>
                        <th>Category</th>
                        <th>Public author</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($blog->id); ?></td>
                            <td><strong><?php echo e($blog->title); ?></strong></td>
                            <td><?php echo e($blog->category_name ?: '—'); ?></td>
                            <td><?php echo e($blog->public_author_name ?: '—'); ?></td>
                            <td><?php echo e($blog->IsPublished); ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>
                                        <form
                                            method="POST"
                                            action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>"
                                            onsubmit="return confirm('Delete this blog post?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-button admin-button-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No blog posts found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', ['paginator' => $blogs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>