

<?php $__env->startSection('title', 'All DJ Mixes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All DJ Mixes</h1>

        <a class="admin-button" href="<?php echo e(route('admin.dj-mixes.create')); ?>">
            + Add DJ Mix
        </a>
    </div>

    <div class="admin-panel">
        <form
            class="admin-filters admin-dj-mix-filters"
            method="GET"
            action="<?php echo e(route('admin.dj-mixes.index')); ?>"
        >
            <label class="admin-field">
                Search
                <input
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    placeholder="Mix title or DJ name"
                >
            </label>

            <button class="admin-button" type="submit">Search</button>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Mix / DJ</th>
                        <th>Year</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $mixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($mix->id); ?></td>
                            <td>
                                <strong><?php echo e($mix->mix_title); ?></strong>
                                <br>
                                <?php echo e($mix->dj_name ?: '—'); ?>

                            </td>
                            <td><?php echo e($mix->released_year ?: '—'); ?></td>
                            <td><?php echo e($mix->IsPublished); ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route('admin.dj-mixes.edit', $mix->id)); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>

                                    <form
                                        method="POST"
                                        action="<?php echo e(route('admin.dj-mixes.destroy', $mix->id)); ?>"
                                        onsubmit="return confirm('Delete this DJ mix?')"
                                    >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            class="admin-button admin-button-danger"
                                            type="submit"
                                        >
                                            Delete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No DJ mixes found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', ['paginator' => $mixes], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/dj-mixes/index.blade.php ENDPATH**/ ?>