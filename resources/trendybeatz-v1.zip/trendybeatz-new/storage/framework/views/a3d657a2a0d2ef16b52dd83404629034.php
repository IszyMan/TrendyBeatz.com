<nav class="topnav desktop-nav desktop-nav-primary" aria-label="Desktop primary navigation">
    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>" href="<?php echo e(route('home')); ?>">
        <span aria-hidden="true">⌂</span><br>Home
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.download')]); ?>" href="<?php echo e(route('music.download')); ?>">
        <span aria-hidden="true">♫</span><br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.naija')]); ?>" href="<?php echo e(route('music.naija')); ?>">
        Naija<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('artists.index')]); ?>" href="<?php echo e(route('artists.index')); ?>">
        All<br>Artiste
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/celebrity-news')]); ?>"
        href="<?php echo e(route('blogs.category', 'celebrity-news')); ?>"
    >
        Celebrity<br>News
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/hot-gists')]); ?>"
        href="<?php echo e(route('blogs.category', 'hot-gists')); ?>"
    >
        Hot<br>Gists
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/music-reviews')]); ?>"
        href="<?php echo e(route('blogs.category', 'music-reviews')); ?>"
    >
        Music<br>Reviews
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('blogs.index')]); ?>" href="<?php echo e(route('blogs.index')); ?>">
        News<br>Blog
    </a>
</nav>

<nav id="navRow2" class="topnav desktop-nav navRow2" aria-label="Desktop music navigation">
    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.all')]); ?>" href="<?php echo e(route('music.all')); ?>">
        All<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('albums.index')]); ?>" href="<?php echo e(route('albums.index')); ?>">
        Albums<br>/EP
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.gospel')]); ?>" href="<?php echo e(route('music.gospel')); ?>">
        Gospel<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.ghana')]); ?>" href="<?php echo e(route('music.ghana')); ?>">
        Ghana<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.african')]); ?>" href="<?php echo e(route('music.african')); ?>">
        African<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.highlife')]); ?>" href="<?php echo e(route('music.highlife')); ?>">
        HighLife<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('videos.index')]); ?>" href="<?php echo e(route('videos.index')); ?>">
        Video
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('mixes.index')]); ?>" href="<?php echo e(route('mixes.index')); ?>">
        DJ<br>Mix
    </a>
</nav>

<nav id="mobileNav" class="topnav mobile-nav" aria-label="Mobile navigation">
    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>" href="<?php echo e(route('home')); ?>">
        Home<br>Page
    </a>

    <div class="mobile-dropdown">
        <button
            class="dropbtn <?php echo e(request()->routeIs('music.*', 'albums.*', 'videos.*', 'mixes.*') ? 'active' : ''); ?>"
            type="button"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="musicDropdown"
        >
            Music<br><span aria-hidden="true">▼</span>
        </button>

        <div class="dropdown-content" id="musicDropdown" hidden>
            <a href="<?php echo e(route('music.all')); ?>">All Music</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums/EP</a>
            <a href="<?php echo e(route('music.naija')); ?>">Naija Music</a>
            <a href="<?php echo e(route('music.ghana')); ?>">Ghana Music</a>
            <a href="<?php echo e(route('music.african')); ?>">African Music</a>
            <a href="<?php echo e(route('music.gospel')); ?>">Gospel Music</a>
            <a href="<?php echo e(route('music.highlife')); ?>">Highlife Music</a>
            <a href="<?php echo e(route('videos.index')); ?>">Videos</a>
            <a href="<?php echo e(route('mixes.index')); ?>">DJ Mix</a>
        </div>
    </div>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('music.naija')]); ?>" href="<?php echo e(route('music.naija')); ?>">
        Naija<br>Music
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('artists.index')]); ?>" href="<?php echo e(route('artists.index')); ?>">
        All<br>Artiste
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/celebrity-news')]); ?>"
        href="<?php echo e(route('blogs.category', 'celebrity-news')); ?>"
    >
        Celebrity<br>News
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/hot-gists')]); ?>"
        href="<?php echo e(route('blogs.category', 'hot-gists')); ?>"
    >
        Hot<br>Gists
    </a>

    <a
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->is('blogs/music-reviews')]); ?>"
        href="<?php echo e(route('blogs.category', 'music-reviews')); ?>"
    >
        Music<br>Reviews
    </a>

    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('blogs.index')]); ?>" href="<?php echo e(route('blogs.index')); ?>">
        News<br>Blog
    </a>
</nav>

<div class="search-wrapper">
    <form
        class="search-box"
        method="GET"
        action="<?php echo e(route('search')); ?>"
        role="search"
    >
        <input
            type="search"
            name="q"
            value="<?php echo e(request('q')); ?>"
            placeholder="Search TrendyBeatz.."
            aria-label="Search TrendyBeatz"
            maxlength="200"
            required
        >

        <button type="submit">Search</button>
    </form>

    
</div><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/navigation.blade.php ENDPATH**/ ?>