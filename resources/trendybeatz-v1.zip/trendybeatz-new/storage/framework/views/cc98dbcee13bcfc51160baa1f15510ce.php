<?php
    $commentKey = 'comments-' . $postType . '-' . $postId;

    $commentToken = \App\Support\CommentTarget::token(
        $postType,
        (int) $postId,
        $postTitle
    );

    $approvedComments = \Illuminate\Support\Facades\DB::table('comments')
        ->where('post_type', $postType)
        ->where('post_id', $postId)
        ->where('is_allowed', 1)
        ->select('id', 'name', 'coments')
        ->orderByDesc('id')
        ->paginate(10, ['*'], 'comments_page');
?>

<section
    class="tb-comments"
    id="<?php echo e($commentKey); ?>"
    aria-label="Comments"
>
    <div class="tb-comments-list">
        <h3>
            Comments
            <span>(<?php echo e($approvedComments->total()); ?>)</span>
        </h3>

        <?php $__empty_1 = true; $__currentLoopData = $approvedComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="tb-comment">
                <span
                    class="tb-comment-avatar"
                    aria-hidden="true"
                >
                    <?php echo e(mb_strtoupper(
                        mb_substr($comment->name ?: 'Guest', 0, 1)
                    )); ?>

                </span>

                <div>
                    <strong><?php echo e($comment->name ?: 'Guest'); ?></strong>

                    <p><?php echo e($comment->coments); ?></p>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-comments-empty">
                No comments yet. Share your thoughts below.
            </p>
        <?php endif; ?>

       <?php if($approvedComments->hasPages()): ?>
            <?php echo $__env->make('partials.pagination', [
                'paginator' => $approvedComments
                    ->withQueryString()
                    ->fragment($commentKey),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>

    <div class="tb-comments-heading">
        <h2>Leave a comment</h2>
    </div>

    <form
        class="tb-comment-form"
        action="<?php echo e(route('comments.store')); ?>"
        method="POST"
    >
        <?php echo csrf_field(); ?>

        <input
            type="hidden"
            name="target"
            value="<?php echo e($commentToken); ?>"
        >

        <div class="tb-comment-fields">
            <label for="<?php echo e($commentKey); ?>-name">
                Your name

                <input
                    id="<?php echo e($commentKey); ?>-name"
                    name="name"
                    type="text"
                    required
                    maxlength="191"
                    autocomplete="name"
                    placeholder="Enter your name"
                >
            </label>

            <label for="<?php echo e($commentKey); ?>-email">
                Email <span class="tb-comment-optional">(optional)</span>

                <input
                    id="<?php echo e($commentKey); ?>-email"
                    name="email"
                    type="email"
                    maxlength="191"
                    autocomplete="email"
                    placeholder="you@example.com"
                >
            </label>
        </div>

        <label for="<?php echo e($commentKey); ?>-message">
            Your comment

            <textarea
                id="<?php echo e($commentKey); ?>-message"
                name="message"
                required
                minlength="2"
                maxlength="3000"
                rows="3"
                placeholder="Write your comment…"
            ></textarea>
        </label>

        <div class="tb-comment-footer">
            <p>
                Comments require approval. No links, please.
                Your email stays private.
            </p>

            <button type="submit">
                Submit comment
                <span aria-hidden="true">→</span>
            </button>
        </div>

        <div
            class="tb-comment-feedback"
            role="status"
            aria-live="polite"
            tabindex="-1"
            hidden
        ></div>
    </form>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/comments.blade.php ENDPATH**/ ?>