

<?php
    $pageNumber = $djs->currentPage();

    $pageTitle = 'DJ Profiles & Full Mix';

    if ($pageNumber > 1) {
        $pageTitle .= ' - Page ' . $pageNumber;
    }

    $description = 'Explore Nigerian, Ghanaian and African DJ profiles '
        . 'on TrendyBeatz. Discover your favourite DJs, read their '
        . 'biographies and browse their latest mixes and mixtapes.';

    $keywords = 'DJ profiles, latest DJ mix, DJ mixtapes, '
        . 'Nigerian DJs, Ghanaian DJs, African DJs, '
        . 'DJ Spinall, DJ Neptune, DJ Cuppy';

    $canonical = $pageNumber === 1
        ? route('djs.index')
        : route('djs.index', ['page' => $pageNumber]);
?>

<?php $__env->startSection('title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('meta_keywords', $keywords); ?>
<?php $__env->startSection('meta_description', $description); ?>
<?php $__env->startSection('canonical', $canonical); ?>
<?php $__env->startSection('social_title', $pageTitle . ' | TrendyBeatz'); ?>
<?php $__env->startSection('social_description', $description); ?>

<?php $__env->startSection('content'); ?>
    <section class="tb-artists-page tb-djs-page">
        <header class="tb-artists-header">
            <h1 class="section-heading">
               Discover Nigerian, Ghanaian and African DJ Profiles & Mixes
            </h1>

          <!--  <p class="tb-artists-intro">
                Discover your favourite DJs and explore their mixtapes
                on TrendyBeatz. Open a DJ’s profile to read about them,
                browse their releases and find listening and download
                options.
            </p>-->

            <p class="home-date">
                <time datetime="<?php echo e(now()->toDateString()); ?>">
                    <?php echo e(now()->format('M d, Y')); ?>

                </time>
            </p>
        </header>

        <section class="tb-artists-popular">
            <h2 class="sub-section-heading">
                Browse DJ Profiles
            </h2>

            <div class="tb-artists-grid">
                <?php $__empty_1 = true; $__currentLoopData = $djs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $djName = trim((string) $dj->dj_name);

                        $djSlug = trim((string) ($dj->slug ?? ''));

                        if ($djSlug === '') {
                            $djSlug = \Illuminate\Support\Str::slug($djName);
                        }

                        $photo = trim((string) ($dj->photo ?? ''));

                        if ($photo === '') {
                            $photoUrl = null;
                        } elseif (preg_match('~^https?://~i', $photo)) {
                            $photoUrl = $photo;
                        } else {
                            $photoPath = ltrim($photo, '/');

                            $photoUrl = asset(
                                str_starts_with($photoPath, 'images/')
                                    ? $photoPath
                                    : 'images/' . $photoPath
                            );
                        }
                    ?>

                    <a
                        class="tb-artist-card"
                        href="<?php echo e(route('djs.show', $djSlug)); ?>"
                    >
                        <span class="tb-artist-card-photo">
                            <span
                                class="tb-artist-card-placeholder"
                                aria-hidden="true"
                            >
                                DJ
                            </span>

                            <?php if($photoUrl): ?>
                                <img
                                    src="<?php echo e($photoUrl); ?>"
                                    alt="<?php echo e($djName); ?> profile"
                                    loading="lazy"
                                    onerror="this.remove()"
                                >
                            <?php endif; ?>
                        </span>

                        <strong class="tb-artist-card-name">
                            <?php echo e($djName); ?>

                        </strong>

                        <span class="tb-artist-card-action">
                            View Profile & Mixtapes →
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="tb-artists-empty">
                        No published DJ profiles available yet.
                    </p>
                <?php endif; ?>
            </div>
        </section>

        <?php if($djs->hasPages()): ?>
            <?php echo $__env->make('partials.pagination', [
                'paginator' => $djs,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/djs.blade.php ENDPATH**/ ?>