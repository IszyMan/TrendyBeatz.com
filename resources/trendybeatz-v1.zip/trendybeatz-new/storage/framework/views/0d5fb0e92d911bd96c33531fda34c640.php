

<?php $__env->startSection('title', 'Edit Artist'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Edit <?php echo e($artist->Stage_Name ?: $artist->ArtistsName); ?></h1>
        <a href="<?php echo e(route('admin.artists.index')); ?>">← All Artists</a>
    </div>

    <?php echo $__env->make('admin.artists.form', ['artist' => $artist], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/artists/edit.blade.php ENDPATH**/ ?>