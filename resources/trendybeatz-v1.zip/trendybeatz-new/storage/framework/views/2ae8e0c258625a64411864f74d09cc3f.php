

<?php $__env->startSection('title', 'Edit Album'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Edit Album #<?php echo e($album->id); ?></h1>
        <a href="<?php echo e(route('admin.albums.index')); ?>">← All Albums</a>
    </div>

    <?php echo $__env->make('admin.albums.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/albums/edit.blade.php ENDPATH**/ ?>