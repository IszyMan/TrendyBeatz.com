

<?php $__env->startSection('title', 'All Artists'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All Artists</h1>

        <a class="admin-button" href="<?php echo e(route('admin.artists.create')); ?>">
            + Add Artist
        </a>
    </div>

    <div class="admin-panel">
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Artist</th>
                        <th>Country</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($artist->Artists_Id); ?></td>
                            <td>
                                <strong>
                                    <?php echo e($artist->Stage_Name ?: $artist->ArtistsName); ?>

                                </strong>
                            </td>
                            <td><?php echo e(ucfirst($artist->country_id)); ?></td>
                            <td><?php echo e($artist->IsPublished); ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route('admin.artists.edit', $artist->id)); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route('admin.artists.destroy', $artist->id)); ?>"
                                            onsubmit="return confirm('Delete this artist?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-button admin-button-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No artists found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', ['paginator' => $artists], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/artists/index.blade.php ENDPATH**/ ?>