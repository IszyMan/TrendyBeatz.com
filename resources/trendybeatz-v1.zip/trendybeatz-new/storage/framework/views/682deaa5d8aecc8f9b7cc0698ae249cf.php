


    <?php
        $countryUrl = route('music.' . $country);

        $canonicalUrl = $songs->currentPage() === 1
            ? $countryUrl
            : $songs->url($songs->currentPage());


        $firstCover = trim(
            (string) ($songs->first()->cover_url ?? '')
        );

        if ($firstCover === '') {
            $socialImage = '';
        } elseif (preg_match('~^https?://~i', $firstCover)) {
            $socialImage = $firstCover;
        } else {
            $coverPath = ltrim($firstCover, '/');

            $socialImage = asset(
                str_starts_with($coverPath, 'images/')
                    ? $coverPath
                    : 'images/' . $coverPath
            );
        }
    ?>

<?php $__env->startSection('title', $page['title']); ?>
<?php $__env->startSection('meta_description', $page['description']); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $page['title']); ?>
<?php $__env->startSection('social_description', $page['description']); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php if($songs->currentPage() > 1): ?>
    <?php $__env->startSection(
        'previous_url',
        $songs->currentPage() === 2
            ? $countryUrl
            : $songs->previousPageUrl()
    ); ?>
<?php endif; ?>

<?php if($songs->hasMorePages()): ?>
    <?php $__env->startSection('next_url', $songs->nextPageUrl()); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<section class="tb-day-page">

    <h1 class="section-heading">
        <?php echo e($page['heading']); ?>

    </h1>

    <?php
        $currentDate = now();
    ?>

    <p class="home-date">
        <time datetime="<?php echo e($currentDate->toDateString()); ?>">
            <?php echo e($currentDate->format('M d, Y')); ?>

        </time>
    </p>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'latest-' . $country . '-songs',
        'heading' => $page['section_heading'],
        'badge' => $page['badge'],
        'items' => $songs,
        'more' => null,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.pagination', [
        'paginator' => $songs,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/music-country.blade.php ENDPATH**/ ?>