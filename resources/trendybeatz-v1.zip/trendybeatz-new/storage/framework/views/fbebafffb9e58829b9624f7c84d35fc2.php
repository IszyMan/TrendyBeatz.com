<section class="tb-home-section tb-home-mixes" id="<?php echo e($id ?? 'latest-dj-mix'); ?>">
    <h2 class="section-heading">
        <?php echo e($heading ?? 'Latest DJ Mix'); ?>

    </h2>

    <div class="tb-home-mix-grid">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                
                $cover = trim((string) $mix->cover_url);

                if ($cover === '') {
                    $coverUrl = null;
                } elseif (preg_match('~^https?://~i', $cover)) {
                    $coverUrl = $cover;
                } else {
                    $coverPath = ltrim($cover, '/');

                    $coverUrl = asset(
                        str_starts_with($coverPath, 'images/')
                            ? $coverPath
                            : 'images/' . basename($coverPath)
                    );
                }
            ?>

            <a
                class="tb-home-mix"
                href="<?php echo e(\App\Support\DjMixUrl::detail($mix)); ?>"
            >
                <span class="tb-home-mix-thumb">
                    <span class="tb-home-mix-placeholder" aria-hidden="true">
                        TrendyMix
                    </span>

                    <?php if($coverUrl): ?>
                        <img
                            src="<?php echo e($coverUrl); ?>"
                            alt="<?php echo e($mix->dj_name); ?> - <?php echo e($mix->mix_title); ?> cover"
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>
                </span>

                <span class="tb-home-mix-info">
                    <span class="tb-home-mix-label">DJ Mix</span>

                    <strong class="tb-home-mix-dj">
                        <?php echo e($mix->dj_name); ?>

                    </strong>

                    <span class="tb-home-mix-title">
                        <?php echo e($mix->mix_title); ?>

                    </span>

                    <span class="tb-home-mix-actions">
                        <span class="tb-home-mix-discover">Discover</span>
                        <span class="tb-home-mix-separator">|</span>
                        <span class="tb-home-mix-listen">Listen</span>
                    </span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-home-empty">
                No DJ mixes available yet.
            </p>
        <?php endif; ?>
    </div>

    <?php if(!empty($more)): ?>
        <div class="tb-home-mix-more">
            <a class="tb-home-view-all" href="<?php echo e($more); ?>">
                View All Latest DJ Mix →
            </a>
        </div>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/home/mixes.blade.php ENDPATH**/ ?>