

<?php
    $pageTitle = 'Download Latest Music Mp3 Here | TrendyBeatz';

    $pageDescription = 'Explore the latest music on TrendyBeatz.'
        . ' Discover published songs from Nigerian, Ghanaian and'
        . ' other African artists, highlife & gospel, browse new releases, and find'
        . ' tracks to stream or download.';

    $baseUrl = route('music.all');

    $canonicalUrl = $songs->currentPage() === 1
        ? $baseUrl
        : $songs->url($songs->currentPage());

    $firstCover = trim((string) (
        $songs->first()->cover_url ?? ''
    ));

    if ($firstCover === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $firstCover)) {
        $socialImage = $firstCover;
    } else {
        $coverPath = ltrim($firstCover, '/');

        $socialImage = asset(
            str_starts_with($coverPath, 'images/')
                ? $coverPath
                : 'images/' . $coverPath
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php if($songs->currentPage() > 1): ?>
    <?php $__env->startSection(
        'previous_url',
        $songs->currentPage() === 2
            ? $baseUrl
            : $songs->previousPageUrl()
    ); ?>
<?php endif; ?>

<?php if($songs->hasMorePages()): ?>
    <?php $__env->startSection('next_url', $songs->nextPageUrl()); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <section class="tb-day-page">
        <h1 class="section-heading">
            Download Latest Music Mp3
        </h1>

        <?php
            $currentDate = now();
        ?>

        <p class="tb-day-page-date">
            <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                <?php echo e($currentDate->format('M d, Y')); ?>

            </time>
        </p>

        <?php echo $__env->make('partials.home.songs', [
            'id' => 'all-music',
            'heading' => 'All Latest Music',
            'badge' => 'Music',
            'items' => $songs,
            'more' => null,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('partials.pagination', [
            'paginator' => $songs,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/music-all.blade.php ENDPATH**/ ?>