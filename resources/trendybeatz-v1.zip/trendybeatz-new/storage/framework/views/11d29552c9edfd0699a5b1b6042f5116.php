

<?php
    $pageTitle = 'Dj Mix - Download Latest Naija DJ Mix - DJ Mixtape | Trendybeatz';

    $pageDescription = 'Discover and listen to the latest Naija DJ mixes and African mixtapes on TrendyBeatz. Explore new Afrobeats mixes and find DJ mixtapes to stream or download.';

    $canonicalUrl = $mixes->currentPage() === 1
        ? route('mixes.index')
        : $mixes->url($mixes->currentPage());

    $firstCover = trim((string) ($mixes->first()->cover_url ?? ''));

    if ($firstCover === '') {
        $socialImage = '';
    } elseif (preg_match('~^https?://~i', $firstCover)) {
        $socialImage = $firstCover;
    } else {
        $coverPath = ltrim($firstCover, '/');

        $socialImage = asset(
            str_starts_with($coverPath, 'images/')
                ? $coverPath
                : 'images/dj/' . basename($coverPath)
        );
    }
?>

<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('meta_description', $pageDescription); ?>
<?php $__env->startSection('canonical', $canonicalUrl); ?>
<?php $__env->startSection('social_title', $pageTitle); ?>
<?php $__env->startSection('social_description', $pageDescription); ?>

<?php if($socialImage !== ''): ?>
    <?php $__env->startSection('social_image', $socialImage); ?>
<?php endif; ?>

<?php if($mixes->currentPage() > 1): ?>
    <?php $__env->startSection(
        'previous_url',
        $mixes->currentPage() === 2
            ? route('mixes.index')
            : $mixes->previousPageUrl()
    ); ?>
<?php endif; ?>

<?php if($mixes->hasMorePages()): ?>
    <?php $__env->startSection('next_url', $mixes->nextPageUrl()); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <section class="tb-day-page">
        <h1 class="section-heading">
            Dj Mix - Download Latest Naija Dj Mix/mixtapes
        </h1>

        <?php
            $currentDate = now();
        ?>

        <p class="home-date">
            <time datetime="<?php echo e($currentDate->toDateString()); ?>">
                <?php echo e($currentDate->format('M d, Y')); ?>

            </time>
        </p>

        <?php echo $__env->make('partials.home.mixes', [
            'id' => 'latest-dj-mix',
            'heading' => 'Latest DJ Mix',
            'items' => $mixes,
            'more' => null,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('partials.pagination', [
            'paginator' => $mixes,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/pages/dj-mixes.blade.php ENDPATH**/ ?>