<section class="tb-home-section tb-home-videos" id="<?php echo e($id ?? 'latest-videos'); ?>">
    <h2 class="sub-section-heading">
        <?php echo e($heading ?? 'Latest Videos'); ?>

    </h2>

    <div class="tb-home-song-list">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $cover = trim((string) $video->cover_url);

                if ($cover === '') {
                    $coverUrl = null;
                } elseif (preg_match('~^https?://~i', $cover)) {
                    $coverUrl = $cover;
                } else {
                    $coverPath = ltrim($cover, '/');

                    $coverUrl = asset(
                        str_starts_with($coverPath, 'images/')
                            ? $coverPath
                            : 'images/' . $coverPath
                    );
                }
            ?>

            <a
                class="tb-home-song tb-home-video"
                href="<?php echo e(\App\Support\VideoUrl::detail($video)); ?>"
                
            >
                <span class="tb-home-song-thumb tb-home-video-thumb">
                    <span class="tb-home-song-placeholder" aria-hidden="true">
                        TrendyViews
                    </span>

                    <?php if($coverUrl): ?>
                        <img
                            src="<?php echo e($coverUrl); ?>"
                            alt="<?php echo e($video->artist_name); ?> - <?php echo e($video->track_title); ?> video"
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>

                    <span class="tb-home-video-play" aria-hidden="true">
                        ▶
                    </span>
                </span>

                <span class="tb-home-song-info">
                    <span class="tb-home-song-badge">Video</span>

                    <strong class="tb-home-song-artist">
                        <?php echo e($video->artist_name ?: 'TrendyBeatz'); ?>

                    </strong>

                    <span class="tb-home-song-title">
                        <?php echo e($video->track_title); ?>

                    </span>

                    <?php if(!empty($video->featuring)): ?>
                        <span class="tb-home-song-featuring">
                            Featuring: <?php echo e($video->featuring); ?>

                        </span>
                    <?php endif; ?>

                    <span class="tb-home-song-actions">
                        <span class="tb-home-discover">Discover</span>
                        <span>|</span>
                        <span class="tb-home-stream">Watch</span>
                    </span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="tb-home-empty">
                No videos available yet.
            </p>
        <?php endif; ?>
    </div>

    <?php if(!empty($more)): ?>
        <div class="tb-home-video-more">
            <a class="tb-home-view-all" href="<?php echo e($more); ?>">
                View All Videos →
            </a>
        </div>
    <?php endif; ?>
</section><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/home/videos.blade.php ENDPATH**/ ?>