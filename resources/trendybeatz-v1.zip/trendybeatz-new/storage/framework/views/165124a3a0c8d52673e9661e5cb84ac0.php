<?php if($paginator->hasPages()): ?>
    <nav class="tb-pagination" aria-label="Page navigation">
        <ul class="tb-pagination-list">
            
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <span
                        class="tb-pagination-link is-disabled"
                        aria-disabled="true"
                        aria-label="Previous page"
                    >
                        ‹
                    </span>
                </li>
            <?php else: ?>
                <li>
                    <a
                        class="tb-pagination-link"
                        href="<?php echo e($paginator->previousPageUrl()); ?>"
                        rel="prev"
                        aria-label="Previous page"
                    >
                        ‹
                    </a>
                </li>
            <?php endif; ?>

            
            <?php
                $startPage = max(1, $paginator->currentPage() - 3);
                $endPage = min($paginator->lastPage(), $paginator->currentPage() + 3);
            ?>

            <?php for($page = $startPage; $page <= $endPage; $page++): ?>
                <li>
                    <?php if($page === $paginator->currentPage()): ?>
                        <span
                            class="tb-pagination-link is-current"
                            aria-current="page"
                        >
                            <?php echo e($page); ?>

                        </span>
                    <?php else: ?>
                        <a
                            class="tb-pagination-link"
                            href="<?php echo e($paginator->url($page)); ?>"
                            aria-label="Page <?php echo e($page); ?>"
                        >
                            <?php echo e($page); ?>

                        </a>
                    <?php endif; ?>
                </li>
            <?php endfor; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a
                        class="tb-pagination-link"
                        href="<?php echo e($paginator->nextPageUrl()); ?>"
                        rel="next"
                        aria-label="Next page"
                    >
                        ›
                    </a>
                </li>
            <?php else: ?>
                <li>
                    <span
                        class="tb-pagination-link is-disabled"
                        aria-disabled="true"
                        aria-label="Next page"
                    >
                        ›
                    </span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/partials/pagination.blade.php ENDPATH**/ ?>