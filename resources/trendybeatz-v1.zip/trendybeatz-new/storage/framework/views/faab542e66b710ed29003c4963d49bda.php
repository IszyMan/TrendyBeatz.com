<?php
    $editing = $dj !== null;
?>

<form
    class="admin-panel admin-form-grid"
    method="POST"
    enctype="multipart/form-data"
    action="<?php echo e($editing
        ? route('admin.djs.update', $dj->id)
        : route('admin.djs.store')); ?>"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <label class="admin-field">
        DJ name

        <input
            type="text"
            name="dj_name"
            maxlength="191"
            value="<?php echo e(old('dj_name', $dj->name ?? '')); ?>"
            required
        >
    </label>

    <label class="admin-field">
        Full name

        <input
            type="text"
            name="fullname"
            maxlength="191"
            value="<?php echo e(old('fullname', $dj->full_name ?? '')); ?>"
        >
    </label>

    <label class="admin-field">
        Country

        <select name="country_id">
            <option
                value=""
                <?php if(old('country_id', $dj->country_key ?? '') === ''): echo 'selected'; endif; ?>
            >
                Choose country
            </option>

            <?php $__currentLoopData = [
                'naija' => 'Naija',
                'ghana' => 'Ghana',
                'african' => 'African',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($value); ?>"
                    <?php if(
                        old('country_id', $dj->country_key ?? '') === $value
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label class="admin-field admin-field-wide">
        DJ biography

        <textarea
            name="place_of_birth"
            rows="10"
            placeholder="Write the DJ biography..."
        ><?php echo e(old('place_of_birth', $dj->place_of_birth ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        DJ photo

        <input
            type="file"
            name="photo_upload"
            accept="image/jpeg,image/png,image/webp,image/gif"
        >

        <?php if($editing && filled($dj->profile_img)): ?>
            <small>
                Current image: <?php echo e($dj->profile_img); ?>

            </small>
        <?php endif; ?>
    </label>

    <input type="hidden" name="IsPublished" value="NO">

    <div class="admin-checks admin-field-wide">
        <label>
            <input
                type="checkbox"
                name="IsPublished"
                value="YES"
                <?php if(
                    old('IsPublished', $dj->IsPublished ?? 'NO') === 'YES'
                ): echo 'checked'; endif; ?>
            >

            Published
        </label>
    </div>

    <div class="admin-field-wide">
        <button class="admin-button" type="submit">
            <?php echo e($editing ? 'Save Changes' : 'Create DJ'); ?>

        </button>
    </div>
</form><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/djs/form.blade.php ENDPATH**/ ?>