

<?php $__env->startSection('title', 'All DJs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>All DJs</h1>

        <a class="admin-button" href="<?php echo e(route('admin.djs.create')); ?>">
            + Add DJ
        </a>
    </div>

    <div class="admin-panel">
        <form
            class="admin-filters admin-dj-filters"
            method="GET"
            action="<?php echo e(route('admin.djs.index')); ?>"
        >
            <label class="admin-field">
                Search
                <input
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    placeholder="DJ name or full name"
                >
            </label>

            <button class="admin-button" type="submit">Search</button>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>DJ</th>
                        <th>Country</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $djs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($dj->id); ?></td>
                            <td>
                                <strong><?php echo e($dj->dj_name); ?></strong>
                                <?php if($dj->fullname): ?>
                                    <br><?php echo e($dj->fullname); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e(ucfirst($dj->country_id ?: '—')); ?></td>
                            <td><?php echo e($dj->IsPublished); ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a
                                        class="admin-button"
                                        href="<?php echo e(route('admin.djs.edit', $dj->id)); ?>"
                                    >
                                        Edit
                                    </a>

                                    <?php if(
                                        (int) auth()->user()->roleid
                                            === (int) config('admin.administrator')
                                    ): ?>

                                        <form
                                            method="POST"
                                            action="<?php echo e(route('admin.djs.destroy', $dj->id)); ?>"
                                            onsubmit="return confirm('Delete this DJ?')"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                class="admin-button admin-button-danger"
                                                type="submit"
                                            >
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No DJs found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-pagination">
            <?php echo $__env->make('partials.pagination', ['paginator' => $djs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/djs/index.blade.php ENDPATH**/ ?>