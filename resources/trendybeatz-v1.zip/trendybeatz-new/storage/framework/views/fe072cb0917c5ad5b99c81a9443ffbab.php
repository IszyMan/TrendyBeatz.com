

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-page-head">
        <h1>Dashboard</h1>
    </div>

    <div class="admin-stats">
        <?php if($listingCount !== null): ?>
            <div class="admin-stat">
                Listings
                <strong><?php echo e(number_format($listingCount)); ?></strong>
            </div>
        <?php endif; ?>

        <?php if($mixCount !== null): ?>
            <div class="admin-stat">
                DJ Mixes
                <strong><?php echo e(number_format($mixCount)); ?></strong>
            </div>
        <?php endif; ?>

        <?php if($blogCount !== null): ?>
            <div class="admin-stat">
                Blogs
                <strong><?php echo e(number_format($blogCount)); ?></strong>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>