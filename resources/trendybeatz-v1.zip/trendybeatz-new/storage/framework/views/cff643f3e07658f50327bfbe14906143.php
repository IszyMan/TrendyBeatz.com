<?php
    $editing = $mix !== null;

    $selectedDj = (string) old(
        'dj_id',
        $mix->dj_id ?? ''
    );
?>

<form
    class="admin-panel admin-form-grid"
    method="POST"
    enctype="multipart/form-data"
    action="<?php echo e($editing
        ? route('admin.dj-mixes.update', $mix->id)
        : route('admin.dj-mixes.store')); ?>"
>
    <?php echo csrf_field(); ?>

    <?php if($editing): ?>
        <?php echo method_field('PUT'); ?>

        <p class="admin-field-wide">
            <strong>Mix ID:</strong> <?php echo e($mix->id); ?>

        </p>
    <?php endif; ?>

    <?php if(!$editing): ?>
        <label class="admin-field">
            Mix ID (optional)

            <input
                type="number"
                name="mix_id"
                min="1"
                step="1"
                value="<?php echo e(old('mix_id')); ?>"
                placeholder="Leave blank for automatic ID"
            >

            <small>
                Enter an unused ID, or leave blank to assign one automatically.
            </small>

            <?php $__errorArgs = ['mix_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: #b91c1c;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
    <?php endif; ?>

    <label class="admin-field">
        DJ

        <select name="dj_id" required>
            <option value="">Choose DJ</option>

            <?php $__currentLoopData = $djs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($dj->id); ?>"
                    <?php if($selectedDj === (string) $dj->id): echo 'selected'; endif; ?>
                >
                    <?php echo e($dj->name ?: $dj->full_name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>

    <label class="admin-field">
        Mix title

        <input
            type="text"
            name="mix_title"
            maxlength="191"
            value="<?php echo e(old('mix_title', $mix->title ?? '')); ?>"
            required
        >
    </label>

    <label class="admin-field">
        Release year

        <input
            type="number"
            name="released_year"
            min="1900"
            max="2099"
            step="1"
            value="<?php echo e(old('released_year', $mix->released_year ?? '')); ?>"
        >
    </label>

    <label class="admin-field">
        Audio filename

        <input
            type="text"
            name="track_url"
            maxlength="191"
            value="<?php echo e(old('track_url', $mix->track_url ?? '')); ?>"
            placeholder="e.g Dj-Mix-File-Name-(TrendyBeatz.com).mp3"
        >

        <small>
            Enter the filename only, without a URL or folder.
            <?php if($editing): ?>
                Leave blank to keep the existing filename.
            <?php endif; ?>
        </small>
    </label>

    <label class="admin-field admin-field-wide">
        Introduction

        <textarea
            name="introduction"
            rows="4"
        ><?php echo e(old('introduction', $mix->introduction ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Details

        <textarea
            name="details"
            rows="4"
        ><?php echo e(old('details', $mix->details ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Additional details

        <textarea
            name="details2"
            rows="4"
        ><?php echo e(old('details2', $mix->details2 ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Description 1

        <textarea
            name="description1"
            rows="6"
        ><?php echo e(old('description1', $mix->description1 ?? '')); ?></textarea>
    </label>

    <label class="admin-field admin-field-wide">
        Description 2

        <textarea
            name="description2"
            rows="6"
        ><?php echo e(old('description2', $mix->description2 ?? '')); ?></textarea>
    </label>

    <label class="admin-field">
        Front cover

        <input
            type="file"
            name="cover_image"
            accept="image/jpeg,image/png,image/webp,image/gif"
        >

        <?php if($editing && filled($mix->cover_url)): ?>
            <small>
                Current image: <?php echo e($mix->cover_url); ?>

            </small>
        <?php endif; ?>
    </label>

    <label class="admin-field">
        Back cover

        <input
            type="file"
            name="back_cover_image"
            accept="image/jpeg,image/png,image/webp,image/gif"
        >

        <?php if($editing && filled($mix->back_cover)): ?>
            <small>
                Current image: <?php echo e($mix->back_cover); ?>

            </small>
        <?php endif; ?>
    </label>

    <input type="hidden" name="IsPublished" value="NO">

    <div class="admin-checks admin-field-wide">
        <label>
            <input
                type="checkbox"
                name="IsPublished"
                value="YES"
                <?php if(
                    old(
                        'IsPublished',
                        (int) ($mix->is_published ?? 0) === 1 ? 'YES' : 'NO'
                    ) === 'YES'
                ): echo 'checked'; endif; ?>
            >

            Published
        </label>
    </div>

    <div class="admin-field-wide">
        <button
            class="admin-button"
            type="submit"
            <?php if($djs->isEmpty()): echo 'disabled'; endif; ?>
        >
            <?php echo e($editing ? 'Save Changes' : 'Create DJ Mix'); ?>

        </button>

        <?php if($djs->isEmpty()): ?>
            <p>Create a DJ profile before adding a mix.</p>
        <?php endif; ?>
    </div>
</form><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/admin/dj-mixes/form.blade.php ENDPATH**/ ?>