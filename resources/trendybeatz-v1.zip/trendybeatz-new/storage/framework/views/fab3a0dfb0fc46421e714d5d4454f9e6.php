<?php $__env->startSection(
    'title',
    'TrendyBeatz - Nigeria No. 1 Entertainment and Music Discovery Website For Legal Downloads'
); ?>

<?php $__env->startSection(
    'meta_keywords',
    'TrendyBeatz, latest Nigerian music, Naija music, music discovery, legal music downloads, download music mp3, stream music, Ghana music, African music, gospel songs, highlife music, music videos, albums, EP downloads, DJ mixes, mixtapes, music reviews, entertainment news, artiste profiles, music promotion'
); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="section-heading">
        Discover Latest Naija Music and Entertainment
    </h1>

    <p class="home-date">
        <time datetime="<?php echo e(now()->toDateString()); ?>">
            <?php echo e(now()->format('M d, Y')); ?>

        </time>
    </p>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'song-of-the-day',
        'heading' => 'Song of the Day',
        'badge' => 'Song of the Day',
        'items' => $day,
        'more' => route('songs.day'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'naija',
        'heading' => 'Latest Naija Songs',
        'badge' => 'Naija Music',
        'items' => $naija,
        'more' => route('music.naija'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.blogs', [
        'id' => 'latest-blog-news',
        'heading' => 'Latest Blog & News',
        'placeholder' => 'TrendyNews',
        'items' => $news,
        'more' => route('blogs.index'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'song-of-the-week',
        'heading' => 'Song of the Week',
        'badge' => 'Song of the Week',
        'items' => $week,
        'more' => route('songs.week'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'ghana',
        'heading' => 'Latest Ghana Songs',
        'badge' => 'Ghana Music',
        'items' => $ghana,
        'more' => route('music.ghana'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'african',
        'heading' => 'Latest African Songs',
        'badge' => 'African Music',
        'items' => $african,
        'more' => route('music.african'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.albums', [
        'id' => 'latest-albums',
        'heading' => 'Latest Albums',
        'items' => $albums,
        'more' => route('albums.index'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'gospel',
        'heading' => 'Latest Gospel Songs',
        'badge' => 'Gospel Music',
        'items' => $gospel,
        'more' => route('music.gospel'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.home.songs', [
        'id' => 'highlife',
        'heading' => 'Latest Highlife Songs',
        'badge' => 'Highlife Music',
        'items' => $highlife,
        'more' => route('music.highlife'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    

    <?php echo $__env->make('partials.home.mixes', [
        'id' => 'latest-dj-mix',
        'heading' => 'Latest DJ Mix',
        'badge' => 'DJ Mix',
        'items' => $mixes,
        'more' => route('mixes.index'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    

    <?php echo $__env->make('partials.home.videos', [
        'id' => 'latest-videos',
        'heading' => 'Latest Videos',
        'badge' => 'Video',
        'items' => $videos,
        'more' => route('videos.index'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    

    <?php echo $__env->make('partials.home.blogs', [
        'id' => 'music-reviews',
        'heading' => 'Music Reviews & News',
        'placeholder' => 'TrendyReviews',
        'items' => $reviews,
        'more' => route('blogs.index'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\trendybeatz-new\resources\views/home.blade.php ENDPATH**/ ?>