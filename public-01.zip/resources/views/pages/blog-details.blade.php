@extends('layouts.app')

@php
    $pageTitle = $post->title . ' — TrendyBeatz';

    $cleanMetaText = static function ($text): string {
        return trim(preg_replace(
            '/\s+/u',
            ' ',
            html_entity_decode(
                strip_tags((string) $text),
                ENT_QUOTES | ENT_HTML5,
                'UTF-8'
            )
        ));
    };

    $hideDescriptionFromSource = (int) ($post->hide_from_source ?? 0) === 1;

    $pageDescription = collect([
        $post->intro ?? '',
        $hideDescriptionFromSource ? '' : ($post->description ?? ''),
    ])
        ->map($cleanMetaText)
        ->filter(fn ($text) => $text !== '')
        ->implode(' ');

    if ($pageDescription === '') {
        $pageDescription = 'Read ' . $post->title
            . ' and more news on TrendyBeatz.';
    }

    $pageDescription = \Illuminate\Support\Str::limit(
        $pageDescription,
        260,
        ''
    );

    $metaKeywords = collect([
        $cleanMetaText($post->title),
        $cleanMetaText($post->keywords ?? ''),
        $cleanMetaText($post->category_name ?? ''),
        'TrendyBeatz blog',
        'TrendyBeatz news',
    ])
        ->filter(fn ($value) => $value !== '')
        ->unique()
        ->implode(', ');

    $canonicalUrl = route('blogs.show', $post->slug);

    $cover = trim((string) ($post->photo ?? ''));

    $socialImage = '';
    $socialImageSize = null;

    if ($cover !== '') {
        if (preg_match('~^https?://~i', $cover)) {
            $socialImage = $cover;
        } else {
            $coverPath = ltrim($cover, '/');

            $coverPath = str_starts_with($coverPath, 'images/blog/')
                ? $coverPath
                : 'images/blog/' . basename($coverPath);

            $socialImage = asset($coverPath);

            $localCoverPath = public_path($coverPath);

            if (is_file($localCoverPath)) {
                $socialImageSize = @getimagesize($localCoverPath);
            }
        }
    }
@endphp

    



@section('title', $pageTitle)
@section('meta_description', $pageDescription)
@section('meta_keywords', $metaKeywords)
@section('canonical', $canonicalUrl)

@section('social_type', 'article')
@section('social_title', $post->title)
@section('social_description', $pageDescription)

@if ($socialImage !== '')
    @section('social_image', $socialImage)

    @if ($socialImageSize)
        @section('social_image_width', (string) $socialImageSize[0])
        @section('social_image_height', (string) $socialImageSize[1])
    @endif
@endif



@section('content')
    @php
        $postedAt = $post->updated_at
            ? \Illuminate\Support\Carbon::parse($post->updated_at)
            : null;

        $categoryClasses = [
            'sport-news' => 'tb-blog-sport',
            'celebrity-news' => 'tb-blog-celebrity',
            'hot-gists' => 'tb-blog-gists',
            'networth' => 'tb-blog-networth',
            'music-reviews' => 'tb-blog-reviews',
            'education' => 'tb-blog-education',
            'articles' => 'tb-blog-articles',
            'news' => 'tb-blog-news',
        ];

        $categoryClass = $categoryClasses[$post->category_slug]
            ?? 'tb-blog-news';
    
        
        $imageUrl = function ($value) {
            $image = trim((string) $value);

            if ($image === '') {
                return null;
            }

            if (preg_match('~^https?://~i', $image)) {
                return $image;
            }

            $path = ltrim($image, '/');

            return asset(
                str_starts_with($path, 'images/blog/')
                    ? $path
                    : 'images/blog/' . basename($path)
            );
        };

        $contentBlocks = [
            ['text', $post->description],
            ['text', $post->desc2],
            ['text', $post->desc3],
            ['image', $post->photo2],
            ['text', $post->desc4],
            ['text', $post->desc5],
            ['text', $post->desc6],
            ['image', $post->photo3],
            ['text', $post->desc7],
            ['text', $post->desc8],
            ['text', $post->desc9],
            ['image', $post->photo4],
            ['text', $post->desc10],
            ['text', $post->Desc11],
            ['text', $post->Desc12],
            ['text', $post->Desc13],
            ['image', $post->photo5],
            ['text', $post->Desc14],
            ['text', $post->Desc15],
            ['text', $post->Desc16],
            ['image', $post->photo6],
            ['text', $post->Desc17],
            ['text', $post->Desc18],
            ['text', $post->Desc19],
            ['image', $post->photo7],
            ['text', $post->Desc20],
            ['text', $post->Desc21],
            ['text', $post->Desc22],
            ['text', $post->Desc23],
            ['image', $post->photo8],
            ['text', $post->Desc24],
            ['text', $post->Desc25],
            ['text', $post->Desc26],
            ['image', $post->photo9],
            ['text', $post->Desc27],
            ['text', $post->Desc28],
            ['text', $post->Desc29],
            ['image', $post->photo10],
            ['text', $post->Desc30],
        ];

        $readingParts = [(string) ($post->intro ?? '')];

        foreach ($contentBlocks as [$type, $value]) {
            if ($type === 'text' && filled($value)) {
                $readingParts[] = (string) $value;
            }
        }

        $readingText = implode(' ', $readingParts);

        // Remove markup while preserving spaces between paragraphs.
        $readingText = preg_replace('/<[^>]*>/u', ' ', $readingText);

        $readingText = html_entity_decode(
            $readingText,
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );

        $words = preg_split(
            '/[\s\p{Z}]+/u',
            trim($readingText),
            -1,
            PREG_SPLIT_NO_EMPTY
        );

        $wordCount = count($words ?: []);

        $readingMinutes = max(1, (int) ceil($wordCount / 200));
    @endphp

    <div class="tb-article-page">
        <nav class="tb-article-breadcrumbs" aria-label="Breadcrumb">
            <a href="{{ route('home') }}">Home</a>
            <span aria-hidden="true">→</span>
        
            <a href="{{ route('blogs.index') }}">Blog</a>
        
            @if ($post->category_slug)
                <span aria-hidden="true">→</span>
        
                <a href="{{ route('blogs.category', $post->category_slug) }}">
                    {{ $post->category_name }}
                </a>
            @endif
        
            <span class="tb-article-title-separator" aria-hidden="true">→</span>
        
            <span aria-current="page">
                {{ $post->title }}
            </span>
        </nav>

        <nav class="tb-article-categories" aria-label="Blog categories">
            <a
                class="tb-article-category-link"
                href="{{ route('blogs.index') }}"
            >
                All
            </a>

            @foreach ($categories as $category)
                <a
                    href="{{ route('blogs.category', $category->slug) }}"
                    @class([
                        'tb-article-category-link',
                        'active' => $category->id === $post->category_id,
                    ])
                >
                    {{ $category->name }}
                </a>
            @endforeach
        </nav>

        <article class="tb-article-main">
            <div class="tb-article-cover">
                <span class="tb-article-placeholder" aria-hidden="true">
                    TrendyBlog
                </span>
            
                @if (filled($socialImage))
                    <img
                        src="{{ $socialImage }}"
                        alt="{{ $post->title }}"
                        style="opacity: 0;"
                        onload="this.previousElementSibling.hidden = true; this.parentElement.classList.add('has-image'); this.style.opacity = '1';"
                        onerror="this.remove()"
                    >
                @endif
            </div>

            <div class="tb-article-meta">
                <a
                    class="tb-article-badge {{ $categoryClass }}"
                    href="{{ route('blogs.category', [
                        'category' => $post->category_slug,
                    ]) }}"
                    style="text-decoration: none;"
                >
                    {{ $post->category_name ?: 'News' }}
                </a>

                @if (filled($post->posted_by_name))
                    <span class="tb-article-meta-item">
                        <span aria-hidden="true">✍</span>
                        <a
                            href="{{ route('blogs.published_by', [
                                'slug' => \Illuminate\Support\Str::slug($post->posted_by_name),
                            ]) }}"
                        >
                            <strong>{{ $post->posted_by_name }}</strong>
                        </a>
                    </span>
                @endif

                @if ($postedAt)
                    <span class="tb-article-meta-item">
                        <span aria-hidden="true">🗓</span>
                        <time datetime="{{ $postedAt->toDateString() }}">
                            {{ $postedAt->format('d M Y') }}
                        </time>
                    </span>
                @endif

                <span class="tb-article-meta-item">
                    <span aria-hidden="true">⏱</span>
                    {{ $readingMinutes }} min read
                </span>

                <span class="tb-article-meta-item">
                    <span aria-hidden="true">💬</span>

                    {{ $commentCount }}
                    {{ $commentCount === 1 ? 'comment' : 'comments' }}
                </span>

              
                    <span class="tb-article-meta-item tb-article-meta-updated">
                        Last updated:
                        <time datetime="{{ now()->toDateString() }}">
                            {{ now()->format('M d, Y') }}
                        </time>
                    </span>
              
            </div>

            <h1>{{ $post->title }}</h1>

            @if (filled($post->intro))
                <p class="tb-article-intro">
                    {{ trim(strip_tags((string) $post->intro)) }}
                </p>
            @endif

            <div class="tb-article-body">
                @foreach ($contentBlocks as [$type, $value])
                    @if (filled($value))
                        @if ($type === 'image')
                            @php
                                $inlineImage = $imageUrl($value);
                            @endphp

                            @if ($inlineImage)
                                <figure class="tb-article-body-image">
                                    <img
                                        src="{{ $inlineImage }}"
                                        alt="{{ $post->title }}"
                                        loading="lazy"
                                        onerror="this.closest('figure').remove()"
                                    >
                                </figure>
                            @endif
                        @else
                            @if ($loop->first && $hideDescriptionFromSource)
                                <div
                                    class="tb-article-rich-text"
                                    data-blog-description
                                    data-content-url="{{ route('blogs.description', ['id' => $post->id]) }}"
                                    aria-busy="true"
                                >
                                    <p role="status">Loading...</p>
                                </div>                                
                            @else
                                <div class="tb-article-rich-text">
                                    {!! $value !!}
                                </div>
                            @endif
                        @endif
                    @endif
                @endforeach


            </div>
            
            @if (filled($post->script_url ?? ''))
                <div class="tb-blog-embed">
                    {!! $post->script_url !!}
                </div>
            @endif
            
            @if (filled($post->script_url2 ?? ''))
                <div class="tb-blog-embed">
                    {!! $post->script_url2 !!}
                </div>
            @endif

            <p class="tb-article-source">
                <strong>Source:</strong>
                <a href="{{ route('home') }}">TrendyBeatz</a>
            </p>
        </article>


        {{-- The share section  --}}

    <section class="tb-share-card">
        <p class="tb-share-heading">
            🔗 Share this Article with others on
        </p>

        <div class="tb-share-row">
            <button
                type="button"
                class="tb-share-copy"
                onclick="tbCopyPageLink(this)"
                aria-live="polite"
            >Copy Link</button>
            <div class="a2a_kit a2a_kit_size_24 a2a_default_style">
                <a class="a2a_button_facebook"></a>
                <a class="a2a_button_x"></a>
                <a class="a2a_button_email"></a>
                <a class="a2a_button_pinterest"></a>
                <a class="a2a_button_telegram"></a>
                <a class="a2a_button_whatsapp"></a>
            </div>

            
        </div>
    </section>

        @if ($relatedPosts->isNotEmpty())
            <section class="tb-article-panel">
                <h2 class="tb-article-panel-heading">
                    📌 Related Posts
                </h2>

                <div class="tb-article-related-list">
                    @foreach ($relatedPosts as $related)
                        @php
                            $relatedPhoto = $imageUrl($related->photo);

                            $relatedDate = $related->updated_at
                                ? \Illuminate\Support\Carbon::parse(
                                    $related->updated_at
                                )
                                : null;

                            $relatedCategoryClass = $categoryClasses[
                                $related->category_slug
                            ] ?? 'tb-blog-news';
                        @endphp

                        <a
                            class="tb-article-related-card"
                            href="{{ route('blogs.show', $related->slug) }}"
                        >
                            <span class="tb-article-related-image">
                                <span aria-hidden="true">TrendyBlog</span>

                                @if ($relatedPhoto)
                                    <img
                                        src="{{ $relatedPhoto }}"
                                        alt="{{ $related->title }}"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                @endif
                            </span>

                            <span class="tb-article-related-content">
                                <span
                                    class="tb-article-badge {{ $relatedCategoryClass }}"
                                >
                                    {{ $related->category_name ?: 'News' }}
                                </span>

                                <strong>{{ $related->title }}</strong>

                                <small>
                                    @if ($relatedDate)
                                        {{ $relatedDate->format('d M Y') }}
                                    @endif

                                    @if (filled($related->posted_by_name))
                                        ✍ {{ $related->posted_by_name }}
                                    @endif
                                </small>

                                <span class="tb-article-related-read">
                                    Continue Reading →
                                </span>
                            </span>
                        </a>
                    @endforeach
                </div>

                @if ($post->category_slug)
                    <a
                        class="tb-article-panel-more"
                        href="{{ route('blogs.category', $post->category_slug) }}"
                    >
                        View All {{ $post->category_name }} Posts →
                    </a>
                @endif
            </section>
        @endif

        @if ($latestPosts->isNotEmpty())
            <section class="tb-article-panel">
                <h2 class="tb-article-panel-heading">
                    📰 Latest Posts
                </h2>

                <div class="tb-article-related-list">
                    @foreach ($latestPosts as $latest)
                        @php
                            $latestPhoto = $imageUrl($latest->photo);

                            $latestCategoryClass = $categoryClasses[
                                $latest->category_slug
                            ] ?? 'tb-blog-news';

                            $latestDate = filled($latest->updated_at)
                            ? \Illuminate\Support\Carbon::parse($latest->updated_at)
                            : null;
                        @endphp

                        <a
                            class="tb-article-related-card"
                            href="{{ route('blogs.show', $latest->slug) }}"
                        >
                            <span class="tb-article-related-image">
                                <span aria-hidden="true">TrendyBlog</span>

                                @if ($latestPhoto)
                                    <img
                                        src="{{ $latestPhoto }}"
                                        alt="{{ $latest->title }}"
                                        loading="lazy"
                                        onerror="this.remove()"
                                    >
                                @endif
                            </span>

                            <span class="tb-article-related-content">
                                <span
                                    class="tb-article-badge {{ $latestCategoryClass }}"
                                >
                                    {{ $latest->category_name ?: 'News' }}
                                </span>

                                <strong>{{ $latest->title }}</strong>
                                <small>
                                    @if ($latestDate)
                                        <time datetime="{{ $latestDate->toDateString() }}">
                                            {{ $latestDate->format('d M Y') }}
                                        </time>
                                    @endif

                                    @if (filled($latest->posted_by_name))
                                        ✍ {{ $latest->posted_by_name }}
                                    @endif
                                </small>

                                <span class="tb-article-related-read">
                                    Continue Reading →
                                </span>
                            </span>
                        </a>
                    @endforeach
                </div>

                <a
                    class="tb-article-panel-more"
                    href="{{ route('blogs.index') }}"
                >
                    View More News &amp; Gists →
                </a>
            </section>
        @endif

        <section class="tb-article-panel">
            <h2 class="tb-article-panel-heading">
                📁 Browse Categories
            </h2>

            <div class="tb-article-category-footer">
                @foreach ($categories as $category)
                    <a href="{{ route('blogs.category', $category->slug) }}">
                        {{ $category->name }} →
                    </a>
                @endforeach
            </div>
        </section>

        <a class="tb-article-back" href="{{ route('blogs.index') }}">
            <strong>More News &amp; Gists</strong>
            <span>Catch up on all the latest entertainment</span>
            <em>View All Posts →</em>
        </a>
    </div>


    @include('partials.comments', [
        'postType' => 'blog',
        'postId' => $post->id,
        'postTitle' => $post->title,
    ])


    <script>
        (() => {
            const container = document.querySelector('[data-blog-description]');

            if (!container) return;

            async function loadDescription() {
                container.setAttribute('aria-busy', 'true');
                container.replaceChildren();

                const status = document.createElement('p');
                status.setAttribute('role', 'status');
                status.textContent = 'Loading...';
                container.appendChild(status);

                try {
                    const response = await fetch(container.dataset.contentUrl, {
                        method: 'GET',
                        credentials: 'same-origin',
                        cache: 'no-store',
                        headers: {
                            'Accept': 'text/html'
                        },
                        signal: AbortSignal.timeout(15000)
                    });

                    if (!response.ok) {
                        throw new Error('Description could not be loaded.');
                    }

                    const html = await response.text();

                    // Render the saved rich text, as the existing Blade does.
                    container.innerHTML = html;
                } catch (error) {
                    container.replaceChildren();

                    const message = document.createElement('p');
                    message.setAttribute('role', 'status');
                    message.textContent = 'The article could not be loaded.';

                    const retry = document.createElement('button');
                    retry.type = 'button';
                    retry.textContent = 'Try again';
                    retry.addEventListener('click', loadDescription);

                    container.append(message, retry);
                } finally {
                    container.setAttribute('aria-busy', 'false');
                }
            }

            loadDescription();
        })();
    </script>
@endsection