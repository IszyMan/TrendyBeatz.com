@extends('layouts.app')

@php
    $pageTitle = 'Privacy Policy — TrendyBeatz';

    $metaDescription = 'Read the TrendyBeatz privacy policy to learn about information we collect, cookies, third-party links and how to contact us about privacy concerns.';

    $metaKeywords = 'TrendyBeatz privacy policy, personal information, cookies, usage data, third-party links, privacy concerns';

    $canonical = route('page.privacy');
@endphp

@section('title', $pageTitle)
@section('meta_description', $metaDescription)
@section('meta_keywords', $metaKeywords)
@section('canonical', $canonical)
@section('social_title', $pageTitle)
@section('social_description', $metaDescription)

@section('content')
    <style>
        .tb-privacy {
            --privacy-green: #198754;
            width: 100%;
            max-width: 900px;
            margin: 28px auto;
            padding: 0 16px;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
            color: #25332b;
            overflow-wrap: anywhere;
        }

        .tb-privacy * {
            box-sizing: border-box;
        }

        .tb-privacy-header {
            padding: 26px;
            border: 1px solid #dce8df;
            border-top: 4px solid var(--privacy-green);
            border-radius: 8px;
            background: #f3f8f5;
        }

        .tb-privacy-label {
            margin: 0 0 10px;
            color: var(--privacy-green);
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 1.2px;
            text-transform: uppercase;
        }

        .tb-privacy h1 {
            margin: 0 0 12px;
            color: #14251b;
            font-size: clamp(27px, 4vw, 36px);
            font-weight: 800;
            line-height: 1.2;
        }

        .tb-privacy-updated {
            margin: 0;
            color: #617168;
            font-size: 13px;
            line-height: 1.6;
        }

        .tb-privacy-intro {
            margin: 24px 0;
            font-size: 16px;
            line-height: 1.85;
        }

        .tb-privacy-section {
            margin: 0 0 18px;
            padding: 22px 24px;
            border: 1px solid #e0e6e2;
            border-radius: 8px;
            background: #fff;
        }

        .tb-privacy h2 {
            margin: 0 0 12px;
            padding-left: 12px;
            border-left: 3px solid var(--privacy-green);
            color: #14251b;
            font-size: 20px;
            font-weight: 700;
            line-height: 1.4;
        }

        .tb-privacy-section p {
            margin: 0;
            font-size: 15px;
            line-height: 1.9;
        }

        .tb-privacy-contact {
            border-color: #dce8df;
            background: #f3f8f5;
        }

        .tb-privacy a {
            color: #0066cc;
            text-decoration: none;
        }

        .tb-privacy a:hover {
            text-decoration: underline;
        }

        .tb-privacy a:focus-visible {
            outline: 3px solid var(--privacy-green);
            outline-offset: 4px;
        }

        @media (max-width: 600px) {
            .tb-privacy {
                margin: 18px auto;
                padding: 0 12px;
            }

            .tb-privacy-header {
                padding: 20px 16px;
            }

            .tb-privacy-section {
                padding: 18px 16px;
            }

            .tb-privacy h2 {
                font-size: 18px;
            }
        }
    </style>

    <article class="tb-privacy">
        <header class="tb-privacy-header">
            <p class="tb-privacy-label">TrendyBeatz Media</p>

            <h1>Privacy Policy</h1>

            <p class="tb-privacy-updated">
                Last updated {{ date('F Y') }}
            </p>
        </header>

        <p class="tb-privacy-intro">
            Your privacy is important to us. This policy explains
            what information TrendyBeatz collects, how we use it,
            and your choices.
        </p>

        <section class="tb-privacy-section">
            <h2>Information We Collect</h2>

            <p>
                We may collect your name, email address and usage
                data when you interact with our site (e.g. commenting
                or subscribing). We do not sell your personal
                information to third parties.
            </p>
        </section>

        <section class="tb-privacy-section">
            <h2>Cookies</h2>

            <p>
                We use cookies to improve your browsing experience
                and to analyse site traffic. You can disable cookies
                in your browser settings, though some features may
                not function correctly.
            </p>
        </section>

        <section class="tb-privacy-section">
            <h2>Third-Party Links</h2>

            <p>
                Our site may contain links to external websites.
                We are not responsible for the privacy practices
                of those sites.
            </p>
        </section>

        <section class="tb-privacy-section tb-privacy-contact">
            <h2>Contact</h2>

            <p>
                For privacy concerns, email
                <a href="mailto:info@trendybeatz.com">
                    info@trendybeatz.com
                </a>.
            </p>
        </section>
    </article>
@endsection