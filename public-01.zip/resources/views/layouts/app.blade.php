<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-160361676-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-160361676-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MDS67J7');</script>
<!-- End Google Tag Manager -->
    @php
        $metaTitle = html_entity_decode(
            trim($__env->yieldContent(
                'title',
                ($title ?? 'Discover Latest Naija Music and Entertainment')
                    . ' | TrendyBeatz'
            )),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );

        $metaDescription = trim($__env->yieldContent(
            'meta_description',
            'Stream and discover the latest Naija songs, Ghana and African music, videos, DJ mixes, albums and entertainment news.'
        ));

        $canonicalUrl = trim($__env->yieldContent(
            'canonical',
            url()->current()
        ));

        $socialImage = trim($__env->yieldContent('social_image'));
    @endphp

    <title>{{ $metaTitle }}</title>

    @hasSection('meta_keywords')
        <meta name="keywords" content="@yield('meta_keywords')">
    @endif

    <meta name="description" content="{{ $metaDescription }}">

    

    <meta name="author" content="Israel Wonah">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

    <link rel="canonical" href="{{ $canonicalUrl }}">

    @hasSection('previous_url')
        <link rel="prev" href="@yield('previous_url')">
    @endif

    @hasSection('next_url')
        <link rel="next" href="@yield('next_url')">
    @endif

    
    @php
        $socialTitle = trim($__env->yieldContent(
            'social_title',
            $metaTitle
        ));

        $socialDescription = trim($__env->yieldContent(
            'social_description',
            $metaDescription
        ));

        $socialType = trim($__env->yieldContent(
            'social_type',
            'website'
        ));

        $socialImageWidth = trim(
            $__env->yieldContent('social_image_width')
        );

        $socialImageHeight = trim(
            $__env->yieldContent('social_image_height')
        );
    @endphp

    <meta property="og:type" content="{{ $socialType }}">
    <meta property="og:site_name" content="TrendyBeatz">
    <meta property="og:title" content="{{ $socialTitle }}">
    <meta property="og:description" content="{{ $socialDescription }}">
    <meta property="og:url" content="{{ $canonicalUrl }}">

    @if ($socialImage !== '')
        <meta property="og:image" content="{{ $socialImage }}">
        <meta property="og:image:alt" content="{{ $socialTitle }}">

        @if ($socialImageWidth !== '' && $socialImageHeight !== '')
            <meta property="og:image:width" content="{{ $socialImageWidth }}">
            <meta property="og:image:height" content="{{ $socialImageHeight }}">
        @endif
    @endif

    <meta
        name="twitter:card"
        content="{{ $socialImage !== '' ? 'summary_large_image' : 'summary' }}"
    >
    <meta name="twitter:title" content="{{ $socialTitle }}">
    <meta name="twitter:description" content="{{ $socialDescription }}">

    @if ($socialImage !== '')
        <meta name="twitter:image" content="{{ $socialImage }}">
        <meta name="twitter:image:alt" content="{{ $socialTitle }}">
    @endif


    <link rel="stylesheet" href="{{ asset('css/trendybeatz.css') }}">
    <link rel="stylesheet" href="{{ asset('css/trendybeatz-nav.css') }}">
    <link rel="icon" type="image/png" href="{{ asset('images/faviconn.png') }}">
    <link rel="stylesheet" href="{{ asset('css/comments.css') }}">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}?v=1">


<style>



    
</style>

<!--      <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6353967042876840" crossorigin="anonymous"></script>-->
<script>
(function () {
    // ===== Fill in your values, as provided by Taboola =====
    var PUBLISHER_ID = 'trendybeatz-publisher';
    var PAGE_TYPE    = 'article';
    // =======================================================

    var LOADER_URL         = '//cdn.taboola.com/libtrc/'       + PUBLISHER_ID + '/loader.js';
    var LOADER_PRIVACY_URL = '//static.tblcontent.com/libtrc/' + PUBLISHER_ID + '/loader.privacy.js';
    var PIXEL_URL          = 'https://static.qovani.com/libtrc/tr5?type=pixel&publisher=' + PUBLISHER_ID;
    var SCRIPT_ID          = 'tb_loader_script';

    window._taboola = window._taboola || [];

    var pageTypePush = {};
    pageTypePush[PAGE_TYPE] = 'auto';
    _taboola.push(pageTypePush);

    new Image().src = PIXEL_URL;

    var firstScript = document.getElementsByTagName('script')[0];

    function injectLoader(id, src, fallbackSrc) {
        if (document.getElementById(id)) return;
        var s = document.createElement('script');
        s.async = true;
        s.src   = src;
        s.id    = id;
        if (fallbackSrc) {
            s.onerror = function () {
                if (s.parentNode) s.parentNode.removeChild(s);
                injectLoader(SCRIPT_ID + '_fb', fallbackSrc, null);
            };
        }
        firstScript.parentNode.insertBefore(s, firstScript);
    }

    injectLoader(SCRIPT_ID, LOADER_URL, LOADER_PRIVACY_URL);

    if (window.performance && typeof window.performance.mark === 'function') {
        window.performance.mark('tbl_ic');
    }
})();
</script>

<script data-cfasync="false" type="text/javascript" id="clever-core">
    /* <![CDATA[ */
    (function (document, window) {
        var a, c = document.createElement("script"), f = window.frameElement;

        c.id= "CleverCoreLoader107791";
        c.src = "https://scripts.cleverwebserver.com/a25d2cf952aaed65f0c9bf09a2924f24.js";
        c.async = !0;
        c.type = "text/javascript";
        c.setAttribute("data-target",window.name|| (f && f.getAttribute("id")));
        c.setAttribute("data-callback", "put-your-callback-function-here");
        c.setAttribute("data-callback-url-click", "put-your-click-macro-here");
        c.setAttribute("data-callback-url-view", "put-your-view-macro-here");
        try {
            a = parent.document.getElementsByTagName("script")[0] || document.getElementsByTagName("script")[0];
        } catch (e) {
            a = !1;
        }
        a || (a = document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]);
        a.parentNode.insertBefore(c, a);
    })(document, window);
    /* ]]> */
</script>

</head>
<body>
    <header class="site-logo-bar"><a class="site-logo" href="{{ route('home') }}">Trendy<span>Beatz</span></a></header>
    @include('partials.navigation')


    <div class="page-layout">
        <main class="page-main">
            @yield('content')
        </main>

        <aside class="page-aside" aria-label="TrendyBeatz sidebar">
            @include('layouts.aside')
        </aside>
    </div>

    @include('layouts.footer')

    
    
    <!--POPUP JAVASCRIPT-->

    <script>
        (() => {
            const dialog = document.getElementById('tb-copyright-dialog');
            const opener = document.querySelector('[data-copyright-open]');

            if (!dialog || !opener) return;

            const closeButton = dialog.querySelector('[data-copyright-close]');
            const image = dialog.querySelector('.tb-copyright-image');
            const imageError = dialog.querySelector('.tb-copyright-image-error');

            opener.addEventListener('click', () => {
                if (dialog.open) return;

                dialog.showModal();
                document.documentElement.classList.add('tb-copyright-is-open');
            });

            closeButton.addEventListener('click', () => {
                dialog.close();
            });

            dialog.addEventListener('close', () => {
                document.documentElement.classList.remove('tb-copyright-is-open');
                opener.focus();
            });

            // Close when the shaded area outside the popup is clicked.
            dialog.addEventListener('click', (event) => {
                if (event.target !== dialog) return;

                const bounds = dialog.getBoundingClientRect();

                if (
                    event.clientX < bounds.left ||
                    event.clientX > bounds.right ||
                    event.clientY < bounds.top ||
                    event.clientY > bounds.bottom
                ) {
                    dialog.close();
                }
            });

            function showImageError() {
                image.hidden = true;
                image.style.display = 'none';
                imageError.hidden = false;
            }

            image.addEventListener('error', showImageError);

            if (image.complete && image.naturalWidth === 0) {
                showImageError();
            }
        })();
        </script>
    
    
   <!-- COMMENTS  SCRIPT LIKE-->
   <script>
        document.addEventListener('click', async function (event) {
            const button = event.target.closest('.tb-comment-like');
        
            if (!button || button.disabled) {
                return;
            }
        
            const count = button.querySelector('.tb-comment-like-count');
            const feedback = button.nextElementSibling;
        
            button.disabled = true;
            feedback.hidden = true;
        
            try {
                const response = await fetch(button.dataset.likeUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': button.dataset.csrf
                    }
                });
        
                if (!response.ok) {
                    if (response.status === 429) {
                        throw new Error('Please wait a moment before liking again.');
                    }
        
                    if (response.status === 419) {
                        throw new Error('Please refresh the page and try again.');
                    }
        
                    throw new Error('Could not save your like. Please try again.');
                }
        
                const data = await response.json();
        
                count.textContent = new Intl.NumberFormat().format(
                    data.likes_count
                );
        
                button.classList.add('has-liked');
            } catch (error) {
                feedback.textContent = error.message || 'Please try again.';
                feedback.hidden = false;
            } finally {
                button.disabled = false;
            }
        });
        </script>
        
        <script src="{{ asset('js/comments.js') }}" defer></script>


     <!-- NAV MENU TOGGLE SCRIPT-->
    <script>
        document.querySelectorAll('[data-nav-toggle]').forEach(function (button) {
            button.addEventListener('click', function () {
                const panel = document.getElementById(button.getAttribute('aria-controls'));
                const open = button.getAttribute('aria-expanded') !== 'true';
                document.querySelectorAll('[data-nav-toggle]').forEach(function (other) {
                    other.setAttribute('aria-expanded', 'false');
                    document.getElementById(other.getAttribute('aria-controls')).hidden = true;
                });
                button.setAttribute('aria-expanded', String(open));
                panel.hidden = !open;
            });
        });
        document.addEventListener('click', function (event) {
            if (event.target.closest('.mobile-dropdown')) return;
            document.querySelectorAll('[data-nav-toggle]').forEach(function (button) {
                button.setAttribute('aria-expanded', 'false');
                document.getElementById(button.getAttribute('aria-controls')).hidden = true;
            });
        });
    </script>
    
    <!--ADD TO ANY SHARE SCRIPT-->
    <script async src="https://static.addtoany.com/menu/page.js"></script>
    <script>
        async function tbCopyPageLink(button) {
            const url = window.location.href;
            let copied = false;

            try {
                await navigator.clipboard.writeText(url);
                copied = true;
            } catch (error) {
                const input = document.createElement('textarea');
                input.value = url;
                input.style.position = 'fixed';
                input.style.opacity = '0';
                document.body.appendChild(input);
                input.select();

                try {
                    copied = document.execCommand('Copy');
                } finally {
                    input.remove();
                    button.focus();
                }
            }

            if (!copied) {
                window.prompt('Copy this link:', url);
                return;
            }

            clearTimeout(button.copyTimer);
            button.textContent = 'Copied!';

            button.copyTimer = setTimeout(() => {
                button.textContent = 'Copy Link' ;
            }, 3000);
        }
    </script>

    
    
    <div id="pg-slot-j0o3a3w5njosj7s2q96qv796"></div>
    <script data-cfasync="false" type="text/javascript">
    /* <![CDATA[ */
        (function (document, window) {
            var oPlacer, oCode = document.createElement("script"), oFrame = window.frameElement;
            oCode.src = "https://js.pmx.bet/j0o3a3w5njosj7s2q96qv796/j0o3a3w5njosj7s2q96qv796.js?20250929="+Math.floor((new Date).getTime()/172800000);
            oCode.async = true; oCode.defer = true; oCode.id = "j0o3a3w5njosj7s2q96qv796"; oCode.type = "text/javascript";
            oCode.setAttribute("data-placeholder", window.name || (oFrame && oFrame.getAttribute("id")));
            try {
                oPlacer = parent.document.getElementsByTagName("script")[0] || document.getElementsByTagName("script")[0];
            } catch (e) { oPlacer = false; }
            oPlacer || (oPlacer = document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]);
            oPlacer.parentNode.insertBefore(oCode, oPlacer);
        })(document, window);
    /* ]]> */
    </script>
    

    <script type="text/javascript">
  window._taboola = window._taboola || [];
  _taboola.push({flush: true});
</script>

<script type="text/javascript">var sc_project=12888478; var sc_invisible=1; var sc_security="bc3f4f7d";</script>
<script type="text/javascript" src="https://www.statcounter.com/counter/counter.js" async></script>
<noscript><div class="statcounter"><a title="Web Analytics" href="https://statcounter.com/" target="_blank"><img class="statcounter" src="https://c.statcounter.com/12888478/0/bc3f4f7d/1/" alt="Web Analytics" referrerPolicy="no-referrer-when-downgrade"></a></div></noscript>

<div class="clever-core-ads"></div>

</body>
</html>
